package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CountrySeedDTO;
import softuni.exam.models.dto.PersonSeedDTO;
import softuni.exam.models.entity.Person;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.PersonRepository;
import softuni.exam.service.PersonService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class PersonServiceImpl implements PersonService {
    private static final String PEOPLE_FILE_PATH = "src/main/resources/files/json/people.json";
    private final PersonRepository personRepository;
    private final CountryRepository countryRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
   private final Gson gson;

    public PersonServiceImpl(PersonRepository personRepository, CountryRepository countryRepository, ModelMapper mapper, ValidatorUtil validatorUtil, Gson gson) {
        this.personRepository = personRepository;
        this.countryRepository = countryRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return personRepository.count() > 0;
    }

    @Override
    public String readPeopleFromFile() throws IOException {
        return Files.readString(Path.of(PEOPLE_FILE_PATH));
    }

    @Override
    public String importPeople() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        PersonSeedDTO[] personSeedDTOS = this.gson.fromJson(
                new FileReader(PEOPLE_FILE_PATH), PersonSeedDTO[].class);

        for (PersonSeedDTO personSeedDTO : personSeedDTOS) {
            Optional<Person> optional = personRepository.findByFirstNameEmailPhone(
                    personSeedDTO.getFirstName(), personSeedDTO.getEmail(), personSeedDTO.getPhone()
            );

            if(!validatorUtil.isValid(personSeedDTO) || optional.isPresent()){
                sb.append("Invalid person");
                sb.append(System.lineSeparator());
                continue;
            }

            Person person = mapper.map(personSeedDTO, Person.class);
            person.setCountry(countryRepository.findById(Long.parseLong(personSeedDTO.getCountry())));

            personRepository.save(person);
            sb.append(String.format("Successfully imported person %s %s%n", person.getFirstName(), person.getLastName()));
        }

        return sb.toString();
    }
}
