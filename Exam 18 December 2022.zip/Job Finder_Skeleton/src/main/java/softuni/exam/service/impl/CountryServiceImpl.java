package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CountrySeedDTO;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CompanyRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.PersonRepository;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
public class CountryServiceImpl implements softuni.exam.service.CountryService {
    private static final String COUNTRIES_FILE_PATH = "src/main/resources/files/json/countries.json";
    private final CountryRepository countryRepository;
    private final CompanyRepository companyRepository;
    private final PersonRepository personRepository;
    private final Gson gson;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;

    public CountryServiceImpl(CountryRepository countryRepository, CompanyRepository companyRepository, PersonRepository personRepository, Gson gson, ValidatorUtil validatorUtil, ModelMapper mapper) {
        this.countryRepository = countryRepository;
        this.companyRepository = companyRepository;
        this.personRepository = personRepository;
        this.gson = gson;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
    }

    @Override
    public boolean areImported() {
        return countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFileContent() throws IOException {
        return Files.readString(Path.of(COUNTRIES_FILE_PATH));
    }

    @Override
    public String importCountries() throws IOException {
        StringBuilder sb = new StringBuilder();
        
        CountrySeedDTO[] countrySeedDTOS = this.gson.fromJson(
                new FileReader(COUNTRIES_FILE_PATH), CountrySeedDTO[].class);

        for (CountrySeedDTO countrySeedDTO : countrySeedDTOS) {
            if(!validatorUtil.isValid(countrySeedDTO)){
                sb.append("Invalid country");
                sb.append(System.lineSeparator());
                continue;
            }

            Country country = mapper.map(countrySeedDTO, Country.class);
            country.setCompanies(companyRepository.findAllByCountry_Name(country.getName()));
            country.setPeople(personRepository.findAllByCountry_Name(country.getName()));

            countryRepository.save(country);

            sb.append(String.format("Successfully imported country %s - %s%n",
                    countrySeedDTO.getName(), countrySeedDTO.getCountryCode()));
        }

        return sb.toString();
    }
}
