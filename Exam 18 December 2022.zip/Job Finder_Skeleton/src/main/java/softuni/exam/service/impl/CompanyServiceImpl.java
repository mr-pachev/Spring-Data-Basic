package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.CompanyRoodDTO;
import softuni.exam.models.dto.CompanySeedDTO;
import softuni.exam.models.entity.Company;
import softuni.exam.repository.CompanyRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.JobRepository;
import softuni.exam.service.CompanyService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class CompanyServiceImpl implements CompanyService {
    private static final String COMPANIES_FILE_PATH = "src/main/resources/files/xml/companies.xml";
    private final CompanyRepository companyRepository;
    private final JobRepository jobRepository;
    private final CountryRepository countryRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
    private final XmlParser xmlParser;

    public CompanyServiceImpl(CompanyRepository companyRepository, JobRepository jobRepository, CountryRepository countryRepository, ModelMapper mapper, ValidatorUtil validatorUtil, XmlParser xmlParser) {
        this.companyRepository = companyRepository;
        this.jobRepository = jobRepository;
        this.countryRepository = countryRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return companyRepository.count() > 0;
    }

    @Override
    public String readCompaniesFromFile() throws IOException {
        return Files.readString(Path.of(COMPANIES_FILE_PATH));
    }

    @Override
    public String importCompanies() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        CompanyRoodDTO companyRoodDTO = xmlParser.fromFile(COMPANIES_FILE_PATH, CompanyRoodDTO.class);

        for (CompanySeedDTO seedDTO : companyRoodDTO.getCompany()) {
            Optional<Company> optional = companyRepository.findByName(seedDTO.getCompanyName());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid company");
                sb.append(System.lineSeparator());
                continue;
            }

            Company company = mapper.map(seedDTO, Company.class);
            company.setJobs(jobRepository.findAllByCompany_Name(company.getName()));
            company.setCountry(countryRepository.findById(Long.parseLong(seedDTO.getCountryId())));

            companyRepository.save(company);

            sb.append(String.format("Successfully imported company %s - %s%n", company.getName(), seedDTO.getCountryId()));
        }


        return sb.toString();
    }
}
