package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.JobRootDTO;
import softuni.exam.models.dto.JobSeedDTO;
import softuni.exam.models.entity.Job;
import softuni.exam.repository.CompanyRepository;
import softuni.exam.repository.JobRepository;
import softuni.exam.service.JobService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;

@Service
public class JobServiceImpl implements JobService {
    private static final String JOBS_FILE_PATH = "src/main/resources/files/xml/jobs.xml";
    private final JobRepository jobRepository;
    private final CompanyRepository companyRepository;
    private final ModelMapper mapper;
    private final XmlParser xmlParser;
    private final ValidatorUtil validatorUtil;

    public JobServiceImpl(JobRepository jobRepository, CompanyRepository companyRepository, ModelMapper mapper, XmlParser xmlParser, ValidatorUtil validatorUtil) {
        this.jobRepository = jobRepository;
        this.companyRepository = companyRepository;
        this.mapper = mapper;
        this.xmlParser = xmlParser;
        this.validatorUtil = validatorUtil;
    }

    @Override
    public boolean areImported() {
        return jobRepository.count() > 0;
    }

    @Override
    public String readJobsFileContent() throws IOException {
        return Files.readString(Path.of(JOBS_FILE_PATH));
    }

    @Override
    public String importJobs() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        JobRootDTO jobRootDTO = xmlParser.fromFile(JOBS_FILE_PATH, JobRootDTO.class);

        for (JobSeedDTO seedDTO : jobRootDTO.getJobSeedDTOS()) {
            Optional<Job> optional = jobRepository.findByTitle(seedDTO.getJobTitle());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid job");
                sb.append(System.lineSeparator());
                continue;
            }

            Job job = mapper.map(seedDTO, Job.class);
            job.setCompany(companyRepository.getById(Long.parseLong(seedDTO.getCompanyId())));
            jobRepository.save(job);

            sb.append(String.format("Successfully imported job %s%n", job.getTitle()));
        }


        return sb.toString();
    }

    @Override
    public String getBestJobs() {
        StringBuilder sb = new StringBuilder();

        Set<Job> jobSet = jobRepository.findAllBySalaryAndHoursAWeek();

        for (Job job : jobSet) {
            sb.append(String.format("Job title %s\n" +
                    "-Salary: %.2f$\n" +
                    "--Hours a week: %fh.\n", job.getTitle(), job.getSalary(), job.getHoursAWeek()));
            sb.append(System.lineSeparator());
        }

        return sb.toString();
    }
}
