package softuni.exam.models.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement(name = "companies")
@XmlAccessorType(XmlAccessType.FIELD)
public class CompanyRoodDTO {
    @XmlElement
    private List<CompanySeedDTO> company;

    public List<CompanySeedDTO> getCompany() {
        return company;
    }

    public void setCompany(List<CompanySeedDTO> company) {
        this.company = company;
    }
}
