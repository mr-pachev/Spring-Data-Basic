package softuni.exam.models.entity;

public enum StatusType {
    unemployed, employed, freelancer
}
