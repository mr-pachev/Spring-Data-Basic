package softuni.exam.models.entity;

import javax.persistence.*;

@Entity
@Table(name = "jobs")
public class Job extends BaseEntity{
    @Column(nullable = false)
    private String title;
    @Column(nullable = false)
    private double salary;
    @Column(nullable = false)
    private double hoursAWeek;
    @Column(nullable = false,columnDefinition = "text")
    private String description;
    @ManyToOne
    private Company company;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getHoursAWeek() {
        return hoursAWeek;
    }

    public void setHoursAWeek(double hoursAWeek) {
        this.hoursAWeek = hoursAWeek;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }
}
