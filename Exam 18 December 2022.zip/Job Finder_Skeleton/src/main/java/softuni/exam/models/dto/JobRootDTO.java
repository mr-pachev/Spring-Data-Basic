package softuni.exam.models.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement(name = "jobs")
@XmlAccessorType(XmlAccessType.FIELD)
public class JobRootDTO {
    @XmlElement(name = "job")
    private List<JobSeedDTO> jobSeedDTOS;

    public List<JobSeedDTO> getJobSeedDTOS() {
        return jobSeedDTOS;
    }

    public void setJobSeedDTOS(List<JobSeedDTO> jobSeedDTOS) {
        this.jobSeedDTOS = jobSeedDTOS;
    }
}
