package com.example.springintro.service;

import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.SelectBook;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface BookService {
    void seedBooks() throws IOException;

    List<Book> findAllBooksAfterYear(int year);

    List<String> findAllAuthorsWithBooksWithReleaseDateBeforeYear(int year);

    List<String> findAllBooksByAuthorFirstAndLastNameOrderByReleaseDate(String firstName, String lastName);

    List<String> findAllBooksByGivenAgeRestriction(String ageRestriction);

    List<String> printAllBooksByGoldsTypeEditionAndCopiesLessThan5000(String type, int copies);

    List<String> getAllBooksByGivenPriceLessThanOrPriceGreaterThan(BigDecimal min, BigDecimal max);
    List<String> getAllBooksByRealiseDateDifferentGivenYear(int year);
    List<String> getAllBooksBeforeGivenDate(String date);
    List<String> getAllBooksWhoContainingGivenLetters(String letters);
    List<String> getAllBookByAuthorWhoLastNameEndingOn(String letters);
    int getAllBookByWhoTitleLengthGreatFromGivenNum(int num);
    SelectBook getBooksFromGivenTitle(String title);
}
