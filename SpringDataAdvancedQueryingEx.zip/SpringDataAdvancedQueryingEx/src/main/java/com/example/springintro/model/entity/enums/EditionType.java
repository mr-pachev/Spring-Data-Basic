package com.example.springintro.model.entity.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
