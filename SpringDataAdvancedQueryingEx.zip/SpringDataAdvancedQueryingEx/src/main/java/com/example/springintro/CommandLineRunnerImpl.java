package com.example.springintro;

import com.example.springintro.model.entity.Book;
import com.example.springintro.model.entity.SelectBook;
import com.example.springintro.service.AuthorService;
import com.example.springintro.service.BookService;
import com.example.springintro.service.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Scanner;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {

    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public CommandLineRunnerImpl(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        Scanner scanner = new Scanner(System.in);
//      seedData();
//      printAllBooksAfterYear(2000);
//      printAllAuthorsNamesWithBooksWithReleaseDateBeforeYear(1990);
//      printAllAuthorsAndNumberOfTheirBooks();
//      printALlBooksByAuthorNameOrderByReleaseDate("George", "Powell");

//        01
//        String inputAgeRestriction =  scanner.nextLine();
//
//        bookService.findAllBooksByGivenAgeRestriction(inputAgeRestriction)
//                .forEach(System.out::println);

//        02
//        bookService.printAllBooksByGoldsTypeEditionAndCopiesLessThan5000("GOLD", 5000)
//                .forEach(System.out::println);

//        03
//        bookService.getAllBooksByGivenPriceLessThanOrPriceGreaterThan(BigDecimal.valueOf(5), BigDecimal.valueOf(40))
//                .forEach(System.out::println);

//        04
//        int year = Integer.parseInt(scanner.nextLine());
//        bookService.getAllBooksByRealiseDateDifferentGivenYear(year)
//                .forEach(System.out::println);

//        05
//        String inputDate =  scanner.nextLine();
//        bookService.getAllBooksBeforeGivenDate(inputDate)
//                .forEach(System.out::println);

//        06
//        String letters =  scanner.nextLine();
//        authorService.getAllAuthorsWhoFirstNameEndedByGivenLetters(letters)
//                .forEach(System.out::println);

//        07
//        String letters =  scanner.nextLine();
//        bookService.getAllBooksWhoContainingGivenLetters(letters)
//                .forEach(System.out::println);

//        08
//        String letters =  scanner.nextLine();
//        bookService.getAllBookByAuthorWhoLastNameEndingOn(letters)
//                .forEach(System.out::println);

//        09
//        int length = Integer.parseInt( scanner.nextLine());
//        int books = bookService.getAllBookByWhoTitleLengthGreatFromGivenNum(length);
//        System.out.println(books);

//        10
//        this.authorService.getWithTotalCopies()
//            .forEach(a -> System.out.println(
//                    a.getFirstName() + " " + a.getLastName() +
//                    " - " + a.getTotalCopies()));

//        11
//        String title = scanner.nextLine();
//        SelectBook currentBook = bookService.getBooksFromGivenTitle(title);
//        System.out.println(currentBook.getTitle() + " " + currentBook.getEditionType() + " "
//                + currentBook.getAgeRestriction() + " " + currentBook.getPrice());
    }

    private void printALlBooksByAuthorNameOrderByReleaseDate(String firstName, String lastName) {
        bookService
                .findAllBooksByAuthorFirstAndLastNameOrderByReleaseDate(firstName, lastName)
                .forEach(System.out::println);
    }

    private void printAllAuthorsAndNumberOfTheirBooks() {
        authorService
                .getAllAuthorsOrderByCountOfTheirBooks()
                .forEach(System.out::println);
    }

    private void printAllAuthorsNamesWithBooksWithReleaseDateBeforeYear(int year) {
        bookService
                .findAllAuthorsWithBooksWithReleaseDateBeforeYear(year)
                .forEach(System.out::println);
    }

    private void printAllBooksAfterYear(int year) {
        bookService
                .findAllBooksAfterYear(year)
                .stream()
                .map(Book::getTitle)
                .forEach(System.out::println);
    }

    private void seedData() throws IOException {
        categoryService.seedCategories();
        authorService.seedAuthors();
        bookService.seedBooks();
    }
}
