package bg.productsshopwithxml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsShopWithXmlApplicationTests {

    @Test
    void contextLoads() {
    }

}
