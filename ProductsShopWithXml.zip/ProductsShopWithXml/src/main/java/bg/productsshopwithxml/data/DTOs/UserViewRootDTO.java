package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.*;

import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserViewRootDTO {
    @XmlElement(name = "user")
    List<UserWithSoldProductsDTO> users;

    public UserViewRootDTO() {
    }

    public List<UserWithSoldProductsDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UserWithSoldProductsDTO> users) {
        this.users = users;
    }
}
