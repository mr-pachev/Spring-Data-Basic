package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.*;

import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserBySoldProductsRootDTO {
    @XmlAttribute(name = "count")
    private Integer count;
    @XmlElement(name = "user")
    private List<UsersWithSoldProductsInfoDTO> users;

    public UserBySoldProductsRootDTO() {
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<UsersWithSoldProductsInfoDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UsersWithSoldProductsInfoDTO> users) {
        this.users = users;
    }
}
