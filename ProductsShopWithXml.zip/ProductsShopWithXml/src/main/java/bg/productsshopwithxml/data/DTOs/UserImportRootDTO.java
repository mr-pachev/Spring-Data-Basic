package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "users")
@XmlAccessorType(XmlAccessType.FIELD)
public class UserImportRootDTO {

    @XmlElement(name = "user")
    private List<UsersImportDTO> users;

    public UserImportRootDTO() {
    }

    public List<UsersImportDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UsersImportDTO> users) {
        this.users = users;
    }
}
