package bg.productsshopwithxml.data.DTOs;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.xml.bind.annotation.*;

import java.util.List;

@XmlRootElement(name = "sold-products")
@XmlAccessorType(XmlAccessType.FIELD)
public class SoldProductsWithCountDTO {
    @XmlAttribute(name = "count")
    private Integer count;
    @XmlElement(name = "product")
    private List<ProductAndPriceDTO> products;

    public SoldProductsWithCountDTO() {
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public List<ProductAndPriceDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductAndPriceDTO> products) {
        this.products = products;
    }
}
