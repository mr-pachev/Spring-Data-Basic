package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "categories")
@XmlAccessorType(XmlAccessType.FIELD)
public class CategoryWithProductsRootDTO {
    @XmlElement(name = "category")
    List<CategoryViewDTO> categories;

    public CategoryWithProductsRootDTO() {
    }

    public List<CategoryViewDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryViewDTO> categories) {
        this.categories = categories;
    }
}
