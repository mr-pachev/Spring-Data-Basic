package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "categories")
@XmlAccessorType(XmlAccessType.FIELD)
public class CategoryImportRootDTO {
    @XmlElement(name = "category")
    private List<CategoryImportDTO> categories;

    public CategoryImportRootDTO() {
    }

    public List<CategoryImportDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryImportDTO> categories) {
        this.categories = categories;
    }
}
