package bg.productsshopwithxml.data.DTOs;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

import java.util.List;

@XmlRootElement(name = "products")
@XmlAccessorType(XmlAccessType.FIELD)
public class ProductOutputRootDTO {
    @XmlElement(name = "product")
    private List<ProductOutputBetweenDTO> products;

    public ProductOutputRootDTO() {
    }

    public List<ProductOutputBetweenDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductOutputBetweenDTO> products) {
        this.products = products;
    }
}
