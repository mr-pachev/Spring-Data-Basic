package bg.productsshopwithxml.service.impl;

import bg.productsshopwithxml.data.DTOs.*;
import bg.productsshopwithxml.data.entities.User;
import bg.productsshopwithxml.repository.UserRepository;
import bg.productsshopwithxml.service.UserService;
import bg.productsshopwithxml.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    public final UserRepository userRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;

    public UserServiceImpl(UserRepository userRepository, ModelMapper mapper, ValidatorUtil validatorUtil) {
        this.userRepository = userRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
    }

    @Override
    public long getCount() {
        return userRepository.count();
    }

    @Override
    public void seedUsers(List<UsersImportDTO> users) {
        users.stream()
                .filter(validatorUtil::isValid)
                .map(u -> mapper.map(u, User.class))
                .forEach(userRepository::save);
    }

    @Override
    public User finaRandomUser() {
        //взима случайно id от хранилещето
        long randomId = ThreadLocalRandom
                .current().nextLong(1, userRepository.count() + 1);

        //прави заявка за user по id(случайното id)
        return userRepository
                .findById(randomId)
                .orElse(null);
    }

    @Override
    public UserViewRootDTO findAllUserWithSoldProducts() {
        UserViewRootDTO userOutputRootDTO = new UserViewRootDTO();

        userOutputRootDTO.setUsers(userRepository.findAllSoldProducts()
                .stream()
                .map(u -> mapper.map(u, UserWithSoldProductsDTO.class))
                .collect(Collectors.toList()));

        return userOutputRootDTO;
    }

    @Override
    public UserBySoldProductsRootDTO getUsersWithSoldProducts() {
        UserBySoldProductsRootDTO userBySoldProductsRootDTO = new UserBySoldProductsRootDTO();

        userBySoldProductsRootDTO.setUsers(userRepository.findBySoldProducts()
                .stream()
                .map(u -> {
                    UsersWithSoldProductsInfoDTO usersWithSoldProductsInfoDTO = mapper.map(u, UsersWithSoldProductsInfoDTO.class);

                    SoldProductsWithCountDTO soldProductsWithCountDTO = new SoldProductsWithCountDTO();


                    soldProductsWithCountDTO.setProducts(u.getSoldProducts()
                            .stream()
                            .map(p -> {
                                ProductAndPriceDTO productAndPriceDTO = new ProductAndPriceDTO();
                                productAndPriceDTO.setName(p.getName());
                                productAndPriceDTO.setPrice(p.getPrice());

                                return productAndPriceDTO;
                            })
                            .collect(Collectors.toList()));
                    soldProductsWithCountDTO.setCount(soldProductsWithCountDTO.getProducts().size());

                    usersWithSoldProductsInfoDTO.getSoldProducts()
                            .stream()
                            .map(p ->{
                                p.setProducts(soldProductsWithCountDTO.getProducts());
                                p.setCount(soldProductsWithCountDTO.getCount());
                                return p;
                            })
                            .collect(Collectors.toList());

                    return usersWithSoldProductsInfoDTO;
                }).collect(Collectors.toList()));
        userBySoldProductsRootDTO.setCount(userBySoldProductsRootDTO.getUsers().size());
        return userBySoldProductsRootDTO;
    }
}
