package bg.productsshopwithxml.service;


import bg.productsshopwithxml.data.DTOs.CategoryImportDTO;
import bg.productsshopwithxml.data.DTOs.CategoryWithProductsRootDTO;
import bg.productsshopwithxml.data.entities.Categories;

import java.util.List;
import java.util.Set;

public interface CategoryService {
    Set<Categories> findRandomCategories();

    long getCount();

    void seedCategories(List<CategoryImportDTO> categories);

    CategoryWithProductsRootDTO finaAllCategoriesWithProducts();
}
