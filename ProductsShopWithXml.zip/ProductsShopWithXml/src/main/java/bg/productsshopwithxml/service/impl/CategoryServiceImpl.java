package bg.productsshopwithxml.service.impl;

import bg.productsshopwithxml.data.DTOs.CategoryImportDTO;
import bg.productsshopwithxml.data.DTOs.CategoryViewDTO;
import bg.productsshopwithxml.data.DTOs.CategoryWithProductsRootDTO;
import bg.productsshopwithxml.data.entities.Categories;
import bg.productsshopwithxml.data.entities.Products;
import bg.productsshopwithxml.repository.CategoryRepository;
import bg.productsshopwithxml.service.CategoryService;
import bg.productsshopwithxml.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final CategoryRepository categoryRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;

    public CategoryServiceImpl(CategoryRepository categoryRepository, ValidatorUtil validatorUtil, ModelMapper mapper) {
        this.categoryRepository = categoryRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
    }

    @Override
    public Set<Categories> findRandomCategories() {
        Set<Categories> categoriesSet = new HashSet<>();
        int categoriesCount = ThreadLocalRandom.current().nextInt(1, 3);    //случайно число от 1 до 2
        long totalCountCategories = categoryRepository.count();                         //броя на категориите

        for (int i = 0; i < categoriesCount; i++) {
            //взима случайно id
            long randomId = ThreadLocalRandom.current().nextLong(1, totalCountCategories + 1);

            Categories CategoryFound = categoryRepository.findById(randomId)
                    .orElse(null);

            categoriesSet.add(CategoryFound);
        };
        return categoriesSet;
    }

    @Override
    public long getCount() {
        return categoryRepository.count();
    }

    @Override
    public void seedCategories(List<CategoryImportDTO> categories) {
        categories.stream()
                .filter(validatorUtil::isValid)
                .map(categoryImportDTO -> mapper.map(categoryImportDTO, Categories.class))
                .forEach(categoryRepository::save);
    }

    @Override
    public CategoryWithProductsRootDTO finaAllCategoriesWithProducts() {
        CategoryWithProductsRootDTO categoryWithProductsRootDTO = new CategoryWithProductsRootDTO();

        categoryWithProductsRootDTO.setCategories(categoryRepository.getAllCategories()
                .stream()
                .map(c -> {
                    CategoryViewDTO categoryViewDTO = mapper.map(c, CategoryViewDTO.class);

                    int productsCount = c.getProducts().size();
                    List<BigDecimal> priceList = c.getProducts().stream()
                            .map(Products::getPrice)
                            .toList();
                    BigDecimal totalSum = priceList.stream()
                            .reduce(BigDecimal.ZERO, BigDecimal::add);
                    double avgPrice = totalSum.doubleValue() / productsCount;

                    categoryViewDTO.setProductsCount(productsCount);
                    categoryViewDTO.setAveragePrice(BigDecimal.valueOf(avgPrice));
                    categoryViewDTO.setTotalRevenue(totalSum);

;                   return categoryViewDTO;
                })
                .collect(Collectors.toList()));

        return categoryWithProductsRootDTO;
    }


}
