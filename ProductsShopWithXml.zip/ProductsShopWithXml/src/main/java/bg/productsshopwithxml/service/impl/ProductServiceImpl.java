package bg.productsshopwithxml.service.impl;

import bg.productsshopwithxml.data.DTOs.ProductImportDTO;
import bg.productsshopwithxml.data.DTOs.ProductImportRootDTO;
import bg.productsshopwithxml.data.DTOs.ProductOutputBetweenDTO;
import bg.productsshopwithxml.data.DTOs.ProductOutputRootDTO;
import bg.productsshopwithxml.data.entities.Products;
import bg.productsshopwithxml.repository.ProductRepository;
import bg.productsshopwithxml.service.CategoryService;
import bg.productsshopwithxml.service.ProductService;
import bg.productsshopwithxml.service.UserService;
import bg.productsshopwithxml.util.ValidatorUtil;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {
    private final ProductRepository productRepository;
    private final UserService userService;

    private final CategoryService categoryService;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;

    public ProductServiceImpl(ProductRepository productRepository, UserService userService, CategoryService categoryService, ValidatorUtil validatorUtil, ModelMapper mapper) {
        this.productRepository = productRepository;
        this.userService = userService;
        this.categoryService = categoryService;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
    }

    @Override
    public long getCount() {
        return productRepository.count();
    }

    @Override
    public void seedProducts(List<ProductImportDTO> products) {
        products.stream()
                .filter(validatorUtil::isValid)
                .map(productDTO -> {
                    Products products1 = mapper.map(productDTO, Products.class);
                    products1.setSeller(userService.finaRandomUser());
                    products1.setCategories(categoryService.findRandomCategories());
                    if (products1.getPrice().compareTo(BigDecimal.valueOf(700L)) > 0) {
                        products1.setBuyer(userService.finaRandomUser());
                    }

                    return products1;
                })
                .forEach(productRepository::save);
    }

    @Override
    public ProductOutputRootDTO productsInRange() {

        ProductOutputRootDTO productOutputRootDTO = new ProductOutputRootDTO();
        productOutputRootDTO.setProducts(productRepository.getProductsByPriceBetweenWhereBuyerIsNull(BigDecimal.valueOf(500L), BigDecimal.valueOf(1000L))
                .stream()
                .map(p -> {
                   ProductOutputBetweenDTO productOutputBetweenDTO = mapper.map(p, ProductOutputBetweenDTO.class);
                   productOutputBetweenDTO.setSeller(String.format(
                           "%s %S", p.getSeller().getFirstName(), p.getSeller().getLastName()));
                   return productOutputBetweenDTO;
                })
                .collect(Collectors.toList()));

        return productOutputRootDTO;

    }
}
