package bg.productsshopwithxml.service;

import bg.productsshopwithxml.data.DTOs.ProductImportDTO;
import bg.productsshopwithxml.data.DTOs.ProductOutputRootDTO;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface ProductService {

    long getCount();

    void seedProducts(List<ProductImportDTO> products);

    ProductOutputRootDTO productsInRange();
}
