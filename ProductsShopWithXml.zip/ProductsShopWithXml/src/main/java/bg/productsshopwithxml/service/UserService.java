package bg.productsshopwithxml.service;

import bg.productsshopwithxml.data.DTOs.UserBySoldProductsRootDTO;
import bg.productsshopwithxml.data.DTOs.UserViewRootDTO;
import bg.productsshopwithxml.data.DTOs.UserWithSoldProductsDTO;
import bg.productsshopwithxml.data.DTOs.UsersImportDTO;
import bg.productsshopwithxml.data.entities.User;

import java.util.List;

public interface UserService {

    long getCount();

    void seedUsers(List<UsersImportDTO> users);

    User finaRandomUser();

    UserViewRootDTO findAllUserWithSoldProducts();

    UserBySoldProductsRootDTO getUsersWithSoldProducts();
}
