package bg.productsshopwithxml.repository;

import bg.productsshopwithxml.data.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Set;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    @Query("SELECT u FROM User u WHERE (SELECT COUNT(p) FROM Products p WHERE p.buyer.id = u.id) > 0 ORDER BY u.lastName, u.firstName")
    List<User> findAllSoldProducts();

    @Query("SELECT u FROM User u WHERE SIZE(u.soldProducts) > 0 ORDER BY SIZE(u.soldProducts) DESC, u.lastName")
    List<User> findBySoldProducts();
}
