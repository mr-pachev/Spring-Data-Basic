package bg.productsshopwithxml.repository;

import bg.productsshopwithxml.data.entities.Products;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Set;

@Repository
public interface ProductRepository extends JpaRepository<Products, Long> {

    @Query("SELECT p FROM Products p WHERE p.buyer IS NULL AND p.price BETWEEN :startRange AND :endRange ORDER BY p.price")
    Set<Products> getProductsByPriceBetweenWhereBuyerIsNull(BigDecimal startRange, BigDecimal endRange);

}
