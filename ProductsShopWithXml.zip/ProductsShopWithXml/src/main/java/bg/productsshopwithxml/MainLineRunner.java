package bg.productsshopwithxml;

import bg.productsshopwithxml.data.DTOs.*;
import bg.productsshopwithxml.service.CategoryService;
import bg.productsshopwithxml.service.ProductService;
import bg.productsshopwithxml.service.UserService;
import bg.productsshopwithxml.util.XmlParser;
import jakarta.xml.bind.JAXBException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

@Component
public class MainLineRunner implements CommandLineRunner {
    private static final String INPUT_FILES_PATH = "src/main/resources/files/";
    private static final String USERS_FILE = "users.xml";
    private static final String CATEGORIES_FILE = "categories.xml";
    private static final String PRODUCTS_FILE = "products.xml";
    private static final String OUT_FILE = "src/main/resources/files/out/";
    private static final String PRODUCTS_IN_RANGE = "products-in-range.xml";
    private static final String SOLD_PRODUCTS = "sold-products.xml";
    private static final String CATEGORIES_STATS = "categories-stats.xml";
    private static final String USERS_BY_SOLD_PRODUCTS = "users-by-sold-products.xml";
    public final UserService userService;
    public final CategoryService categoryService;
    private final ProductService productService;
    private final XmlParser xmlParser;
    private final BufferedReader bufferedReader;

    public MainLineRunner(UserService userService, CategoryService categoryService, ProductService productService, XmlParser xmlParser) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.productService = productService;
        this.xmlParser = xmlParser;
        this.bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    }

    @Override
    public void run(String... args) throws Exception {
            seedData();
        System.out.println("Choice exercise: ");
        int exNum = Integer.parseInt(bufferedReader.readLine());

        switch (exNum){
            case 1 -> getAllProductsWithNoBuyer();
            case 2 -> getAllSoldProducts();
            case 3 -> getCategoryByProductsCount();
            case 4 -> getUsersBySoldProducts();
        }
    }

    private void getUsersBySoldProducts() throws JAXBException {
        UserBySoldProductsRootDTO userBySoldProductsRootDTO = userService.getUsersWithSoldProducts();

        xmlParser.writeToFile(OUT_FILE + USERS_BY_SOLD_PRODUCTS, userBySoldProductsRootDTO);
    }

    //3
    private void getCategoryByProductsCount() throws JAXBException {
        CategoryWithProductsRootDTO categoryWithProductsRootDTO = categoryService.finaAllCategoriesWithProducts();

        xmlParser.writeToFile(OUT_FILE + CATEGORIES_STATS, categoryWithProductsRootDTO);
    }
    //2
    private void getAllSoldProducts() throws JAXBException {
        UserViewRootDTO userViewRootDTO = userService
                .findAllUserWithSoldProducts();

        xmlParser.writeToFile(OUT_FILE + SOLD_PRODUCTS, userViewRootDTO);
    }
    //1
    private void getAllProductsWithNoBuyer() throws JAXBException {
        ProductOutputRootDTO productOutputRootDTO = productService.productsInRange();

        xmlParser.writeToFile(OUT_FILE + PRODUCTS_IN_RANGE, productOutputRootDTO);
    }
    //input Data into DATABASE
    private void seedData() throws JAXBException, FileNotFoundException {
        if(userService.getCount() == 0){
            UserImportRootDTO userImportRootDTO = xmlParser.fromFile(INPUT_FILES_PATH + USERS_FILE, UserImportRootDTO.class);

            userService.seedUsers(userImportRootDTO.getUsers());
        }

        if(categoryService.getCount() == 0){
            CategoryImportRootDTO categoryImportRootDTO = xmlParser.fromFile(INPUT_FILES_PATH + CATEGORIES_FILE, CategoryImportRootDTO.class);

            categoryService.seedCategories(categoryImportRootDTO.getCategories());
        }

        if(productService.getCount() == 0){
            ProductImportRootDTO productImportRootDTO = xmlParser.fromFile(INPUT_FILES_PATH + PRODUCTS_FILE, ProductImportRootDTO.class);
            productService.seedProducts(productImportRootDTO.getProducts());
        }
    }
}
