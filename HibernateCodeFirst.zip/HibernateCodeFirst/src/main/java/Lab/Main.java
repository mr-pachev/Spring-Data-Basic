package Lab;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        PlateNumber plate = new PlateNumber("M2925BP");
        Vehicle car = new Car("Zafira", BigDecimal.TEN, "Petrol", 7, plate);
        Vehicle plane = new Plane("Boing", BigDecimal.TEN, "Kerosene", 100);
        Vehicle truck = new Truck("Volvo", BigDecimal.TEN, "Diesel", 40);
        Vehicle bike = new Bike("Balkan", BigDecimal.ONE, "None");

        em.persist(car);
        em.persist(plane);
        em.persist(truck);
        em.persist(bike);
        em.persist(plate);

        em.getTransaction().commit();
        em.close();
    }
}
