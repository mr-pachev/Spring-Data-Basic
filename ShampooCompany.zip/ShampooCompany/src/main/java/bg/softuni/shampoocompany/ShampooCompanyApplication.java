package bg.softuni.shampoocompany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShampooCompanyApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShampooCompanyApplication.class, args);
    }

}
