package orm;

import annotations.Id;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Objects;

public class EntityManager<E> implements DbContext<E> {

    private Connection connection;
    public EntityManager(Connection connection){
        this.connection = connection;
    }

    @Override
    public boolean persist(E entity) throws IllegalAccessException, SQLException {
        Field primaryKey = getId(entity.getClass());
        primaryKey.setAccessible(true);
        Object value = primaryKey.get(entity);

        if((value == null) || ((long) value <= 0)){
            return doInsert(entity, primaryKey);
        }

        return doUpdate(entity, primaryKey);
    }

    @Override
    public Iterable<E> find(Class<E> table) {
        return null;
    }

    @Override
    public Iterable<E> find(Class<E> table, String where) throws SQLException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Statement statement = connection.createStatement();
        String tableName = getTableNameFromEntity(table);

        String query = String.format("SELECT * FROM %s %s LIMIT 1;",
                tableName, where != null ? " WHERE " + where : "");

        ResultSet resultSet = statement.executeQuery(query);
        E entity = table.getDeclaredConstructor().newInstance();

        resultSet.next();
        fillEntity(table, resultSet, entity);

        return entity;
    }

    private void fillEntity(Class<E> table, ResultSet resultSet, E entity) throws SQLException, IllegalAccessException {
        Field[] declaredFields = Arrays.stream(table.getDeclaredFields())
                .toArray(Field[]::new);

        for (Field field : declaredFields) {
            field.setAccessible(true);
            fillField(field, resultSet, entity);
        }
     }

    private void fillField(Field field, ResultSet resultSet, E entity) throws SQLException, IllegalAccessException {
        if(field.getType() == int.class || field.getType() == long.class){
            field.set(entity, resultSet.getInt(field.getName()));
        }else if(field.getType() ==  LocalDate.class){
            field.set(entity, LocalDate.parse(resultSet.getString(field.getName())));
        }else {
            field.set(entity, resultSet.getString(field.getName()));
        }
    }


    @Override
    public E findFirst(Class<E> table) {
        return null;
    }

    @Override
    public E findFirst(Class<E> table, String where) throws SQLException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        Statement statement = connection.createStatement();
        String tableName = getTableNameFromEntity(table);

        String query = String.format("SELECT * FROM %s %s LIMIT 1;",
                tableName, where != null ? " WHERE " + where : "");

        ResultSet resultSet = statement. executeQuery(query);
        E entity = table.getDeclaredConstructor().newInstance();

        resultSet.next();
        fillEntity(table, resultSet, entity);

        return  entity;
    }

    private Field getId(Class<?> entity){
        return Arrays.stream(entity.getDeclaredFields())
                .filter(x -> x.isAnnotationPresent(Id.class))
                .findFirst()
                .orElseThrow(() -> new UnsupportedOperationException("Entity does not  have primary key"));
    }

    private boolean doInsert(E entity, Field primary) throws SQLException {
        String tableName = this.getTableName(entity.getClass());
        String query = "INSERT INTO " + this.getTableName(entity.getClass()) + " (";

        return connection.prepareStatement(query).execute();
    }

    private boolean doUpdate(E entity, Field primary) throws SQLException {
        String query = "UPDATE " + this.getTableName(entity.getClass()) + " SET ";

        return connection.prepareStatement(query).execute();
    }
}
