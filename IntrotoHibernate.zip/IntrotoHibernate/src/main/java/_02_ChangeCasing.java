import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class _02_ChangeCasing {
    public static void main(String[] args) {
        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("PU_Name");

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        Query selectedTowns = em.createQuery("SELECT t FROM Town t", Town.class);
        List<Town> resultList = selectedTowns.getResultList();

        for(Town t: resultList){
            if(t.getName().length() <= 5){
                t.setName(t.getName().toUpperCase());

                em.persist(t);
            }
        }
        em.getTransaction().commit();
        em.close();
    }
}
