import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.*;
import java.util.stream.Collectors;

public class _08_GetEmployeesWithProject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int inputId = Integer.parseInt(scanner.nextLine());

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");
        EntityManager em = emf.createEntityManager();

       Query query = em.createQuery("SELECT e FROM Employee e" +
                        " WHERE e.id = :id", Employee.class)
                .setParameter("id", inputId);

       List<Employee> employeeList = query.getResultList();

       for(Employee e: employeeList){
          List<Project> projectList = e.getProjects().stream()
                   .sorted(Comparator.comparing(Project::getName))
                   .collect(Collectors.toList());

           System.out.printf("%s %s - %s%n", e.getFirstName(), e.getLastName(), e.getJobTitle());
           projectList.forEach(p -> {
               System.out.println(p.getName());
           });
       }
    }
}
