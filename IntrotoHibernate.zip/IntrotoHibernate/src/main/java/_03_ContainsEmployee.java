import entities.Town;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;
import java.util.Scanner;

public class _03_ContainsEmployee {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] searchedName = scanner.nextLine().split(" ");

        EntityManagerFactory emf =
                Persistence.createEntityManagerFactory("PU_Name");

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Long query = em.createQuery("SELECT COUNT(e) FROM Employee e" +
                                        " WHERE e.firstName = :first_name" +
                                        " AND e.lastName = :last_name", Long.class)
                .setParameter("first_name", searchedName[0])
                .setParameter("last_name", searchedName[1])
                .getSingleResult();

        if (query > 0) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        em.getTransaction().commit();
        em.close();
    }
}
