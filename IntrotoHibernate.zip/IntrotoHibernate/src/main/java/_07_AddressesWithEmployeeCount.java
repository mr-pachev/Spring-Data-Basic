import entities.Address;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class _07_AddressesWithEmployeeCount {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT a FROM Address a" +
                " ORDER BY a.employees.size DESC", Address.class)
                .setMaxResults(10);

        List<Address> addressList = query.getResultList();

        for(Address a: addressList){
            System.out.printf("%s - %d employees%n", a.getText(), a.getEmployees().size());
        }
    }
}
