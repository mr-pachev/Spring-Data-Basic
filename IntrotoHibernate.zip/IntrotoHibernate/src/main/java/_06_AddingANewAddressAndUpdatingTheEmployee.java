import entities.Address;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Scanner;

public class _06_AddingANewAddressAndUpdatingTheEmployee {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String lastName = scanner.nextLine();

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        Address address = new Address();
        address.setText("Vitoshka 15");
        em.persist(address);

        em.createQuery("UPDATE Employee e" +
                        " SET e.address = :address" +
                        " WHERE e.lastName = :name")
                        .setParameter("address", address)
                        .setParameter("name", lastName)
                                .executeUpdate();


        em.getTransaction().commit();
        em.close();
    }
}
