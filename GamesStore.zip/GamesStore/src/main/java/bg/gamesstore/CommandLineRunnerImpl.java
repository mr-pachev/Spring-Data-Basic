package bg.gamesstore;

import bg.gamesstore.model.DTOs.AddGameDTO;
import bg.gamesstore.model.DTOs.EditGameDTO;
import bg.gamesstore.model.DTOs.UserLoginDTO;
import bg.gamesstore.model.DTOs.UserRegisterDTO;
import bg.gamesstore.services.GameService;
import bg.gamesstore.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Scanner;
@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    Scanner scanner = new Scanner(System.in);
    private final UserService userService;
    private final GameService gameService;

    public CommandLineRunnerImpl(UserService userService, GameService gameService) {
        this.userService = userService;
        this.gameService = gameService;
    }

    @Override
    public void run(String... args) throws Exception {

        while (true){
            System.out.println("Enter your commands:");
            String[] inputData =   scanner.nextLine().split("\\|");

            switch (inputData[0]){
                case "RegisterUser" -> userService.registerUser(new UserRegisterDTO(
                        inputData[1],inputData[2],inputData[3], inputData[4]));
                case "LoginUser" -> userService.loginUser(new UserLoginDTO(inputData[1], inputData[2]));
                case "Logout" -> userService.logoutUser();
                case "AddGame" -> gameService.addGame(new AddGameDTO(
                        inputData[1], new BigDecimal(inputData[2]), Float.parseFloat(inputData[3]), inputData[4],
                        inputData[5], inputData[6], inputData[7]));
                case "EditGame" -> gameService.editGame(new EditGameDTO(
                        Integer.parseInt(inputData[1].split("=")[0]),
                        new BigDecimal(inputData[2].split("=")[1]),
                        Float.parseFloat(inputData[3].split("=")[1])));
                case "DeleteGame" -> gameService.deleteGame(Integer.parseInt(inputData[1]));
                case "AllGames" -> gameService.printAllGames();
                case "DetailGame" -> gameService.printGameDetails(inputData[1]);
            }

        }
    }
}
