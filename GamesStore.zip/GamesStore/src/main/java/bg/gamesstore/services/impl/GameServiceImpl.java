package bg.gamesstore.services.impl;

import bg.gamesstore.model.DTOs.AddGameDTO;
import bg.gamesstore.model.DTOs.EditGameDTO;
import bg.gamesstore.model.DTOs.PrintAllGamesDTO;
import bg.gamesstore.model.entities.Game;
import bg.gamesstore.repositories.GameRepository;
import bg.gamesstore.services.GameService;
import bg.gamesstore.util.ValidatorUtil;
import jakarta.validation.ConstraintViolation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class GameServiceImpl implements GameService {
    private final GameRepository gameRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;

    public GameServiceImpl(GameRepository gameRepository, ModelMapper mapper, ValidatorUtil validatorUtil) {
        this.gameRepository = gameRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
    }


    @Override
    public void addGame(AddGameDTO addGameDTO) {
        Set<ConstraintViolation<AddGameDTO>> violations = validatorUtil.getViolations(addGameDTO);

        if(!violations.isEmpty()){
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        Game addedGame = mapper.map(addGameDTO, Game.class);
//        addedGame.setReleaseDate(LocalDate.parse(addGameDTO.getReleaseDate(), DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        gameRepository.save(addedGame);
        System.out.printf("Added %s%n", addGameDTO.getTitle());
    }

    @Override
    public void editGame(EditGameDTO editGameDTO) {
        Game editedGame = gameRepository.findById(editGameDTO.getId())
                .orElse(null);

        if(editedGame == null){
            System.out.println("In correct id.%n");
            return;
        }

        editedGame.setPrice(editGameDTO.getPrice());
        editedGame.setSize(editGameDTO.getSize());

        gameRepository.save(editedGame);
        System.out.printf("Edited %s%n", editedGame.getTitle());
    }

    @Override
    public void deleteGame(int i) {
        Game forDeletedGame = gameRepository.findById(i)
                .orElse(null);

        if(forDeletedGame == null){
            System.out.println("In correct id.%n");
            return;
        }
        gameRepository.deleteById(i);
        System.out.printf("Deleted %s%n", forDeletedGame.getTitle());
    }

    @Override
    public void printAllGames() {
        List<Game> all = gameRepository.findAll();
        all.forEach(game -> System.out.printf("%s %.2f%n", game.getTitle(), game.getPrice()));
    }

    @Override
    public void printGameDetails(String title) {
       Game searchedGame = gameRepository.findByTitle(title);

        System.out.println(String.format("Title: %s%n" +
                "Price: %.2f%n" +
                "Description: %s%n" +
                "Release date: %s", searchedGame.getTitle(), searchedGame.getPrice(), searchedGame.getDescription(), searchedGame.getReleaseDate()));
    }
}
