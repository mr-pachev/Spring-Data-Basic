package bg.gamesstore.services;

import bg.gamesstore.model.DTOs.AddGameDTO;
import bg.gamesstore.model.DTOs.EditGameDTO;
import bg.gamesstore.model.DTOs.PrintAllGamesDTO;

import java.util.Set;

public interface GameService {
    void addGame(AddGameDTO addGameDTO);

    void editGame(EditGameDTO editGameDTO);

    void deleteGame(int i);

    void printAllGames();

    void printGameDetails(String title);
}
