package bg.gamesstore.services;

import bg.gamesstore.model.DTOs.UserLoginDTO;
import bg.gamesstore.model.DTOs.UserRegisterDTO;

public interface UserService {
    void registerUser(UserRegisterDTO userRegisterDTO);

    void loginUser(UserLoginDTO userLoginDTO);

    void logoutUser();
}
