package bg.gamesstore.services.impl;

import bg.gamesstore.model.DTOs.UserLoginDTO;
import bg.gamesstore.model.DTOs.UserRegisterDTO;
import bg.gamesstore.model.entities.User;
import bg.gamesstore.repositories.UserRepository;
import bg.gamesstore.services.UserService;
import bg.gamesstore.util.ValidatorUtil;
import bg.gamesstore.util.ValidatorUtilImpl;
import jakarta.validation.ConstraintViolation;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
    private User loggedInUser;

    public UserServiceImpl(UserRepository userRepository, ModelMapper mapper, ValidatorUtilImpl validatorUtil) {
        this.userRepository = userRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
    }

    @Override
    public void registerUser(UserRegisterDTO userRegisterDTO) {
        if(!userRegisterDTO.getPassword().equals(userRegisterDTO.getConfirmPassword())){
            System.out.println("Wrong confirm password.");
            return;
        }

        Set<ConstraintViolation<UserRegisterDTO>> violations =
                validatorUtil.getViolations(userRegisterDTO);

        if(!violations.isEmpty()){
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        User newUser = mapper.map(userRegisterDTO, User.class);
        userRepository.save(newUser);
    }

    @Override
    public void loginUser(UserLoginDTO userLoginDTO) {
        Set<ConstraintViolation<UserLoginDTO>> violations = validatorUtil.getViolations(userLoginDTO);

        if(!violations.isEmpty()){
            violations.stream()
                    .map(ConstraintViolation::getMessage)
                    .forEach(System.out::println);
            return;
        }

        User searchedUser = userRepository.findByEmailAndPassword(userLoginDTO.getEmail(), userLoginDTO.getPassword())
                .orElse(null);

        if(searchedUser == null){
            System.out.println("Incorrect username / password");
            return;
        }

        loggedInUser = searchedUser;
    }

    @Override
    public void logoutUser() {
        if (loggedInUser == null){
            System.out.println("Cannot log out. No user was logged in.");
        }else {
            loggedInUser = null;
        }
    }
}

