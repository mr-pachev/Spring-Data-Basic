package bg.gamesstore.model.DTOs;

import java.math.BigDecimal;

public class EditGameDTO {
    private int id;
    private BigDecimal price;
    private float size;

    public EditGameDTO() {
    }

    public EditGameDTO(int id, BigDecimal price, float size) {
        this.id = id;
        this.price = price;
        this.size = size;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public float getSize() {
        return size;
    }

    public void setSize(float size) {
        this.size = size;
    }
}
