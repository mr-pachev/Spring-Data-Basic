package bg.gamesstore.model.DTOs;

import java.math.BigDecimal;

public class PrintAllGamesDTO {
    private String title;
    private BigDecimal price;
}
