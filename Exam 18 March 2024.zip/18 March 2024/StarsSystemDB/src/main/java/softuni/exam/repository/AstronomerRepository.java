package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.Star;

import java.util.Optional;
import java.util.Set;

@Repository
public interface AstronomerRepository extends JpaRepository<Astronomer, Long> {
    Optional<Astronomer> findByObservingStar_Id(long id);
    Optional<Astronomer> findByFirstNameAndLastName(String firstName, String lastName);
}
