package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ConstellationSeedDTO;
import softuni.exam.models.entity.Constellation;
import softuni.exam.repository.ConstellationRepository;
import softuni.exam.service.ConstellationService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;

@Service
public class ConstellationServiceImpl implements ConstellationService {
    private final ConstellationRepository constellationRepository;
    private final ModelMapper mapper;
    private final Gson gson;
    private final ValidatorUtil validatorUtil;
    private static final String INPUT_FILE_PATH = "src/main/resources/files/json/";
    public static final String CONSTELLATIONS_PATH = "constellations.json";

    public ConstellationServiceImpl(ConstellationRepository constellationRepository, ModelMapper mapper, Gson gson, ValidatorUtil validatorUtil) {
        this.constellationRepository = constellationRepository;
        this.mapper = mapper;
        this.gson = gson;
        this.validatorUtil = validatorUtil;
    }

    @Override
    public boolean areImported() {
        return constellationRepository.count() > 0;
    }

    @Override
    public String readConstellationsFromFile() throws IOException {
        return Files.readString(Path.of(INPUT_FILE_PATH + CONSTELLATIONS_PATH));
    }

    @Override
    public String importConstellations() throws IOException {
        StringBuilder sb = new StringBuilder();

        ConstellationSeedDTO[] constellationSeedDTOS = this.gson.fromJson(
                new FileReader(INPUT_FILE_PATH + CONSTELLATIONS_PATH), ConstellationSeedDTO[].class);

        for (ConstellationSeedDTO constellationSeedDTO : constellationSeedDTOS) {
            Optional<Constellation> optional = this.constellationRepository.findByName(constellationSeedDTO.getName());

            if(!validatorUtil.isValid(constellationSeedDTO) || optional.isPresent()){
                sb.append("Invalid constellation");
                sb.append(System.lineSeparator());
                continue;
            }

            Constellation constellation = mapper.map(constellationSeedDTO, Constellation.class);
            constellationRepository.save(constellation);

            sb.append(String.format("Successfully imported constellation %s - %s%n",
                    constellationSeedDTO.getName(), constellationSeedDTO.getDescription()));
        }

        return sb.toString();
    }
}
