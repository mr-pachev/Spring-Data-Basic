package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.ConstellationSeedDTO;
import softuni.exam.models.dto.StarSeedDTO;
import softuni.exam.models.entity.Star;
import softuni.exam.repository.AstronomerRepository;
import softuni.exam.repository.ConstellationRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.StarService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Optional;

@Service
public class StarServiceImpl implements StarService {
    private final StarRepository starRepository;
    private final ConstellationRepository constellationRepository;
    private final AstronomerRepository astronomerRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private static final String INPUT_FILE_PATH = "src/main/resources/files/json/";
    private static final String STARS_FILE_PATH = "stars.json";

    private final Gson gson;

    public StarServiceImpl(StarRepository starRepository, ConstellationRepository constellationRepository, AstronomerRepository astronomerRepository, ValidatorUtil validatorUtil, ModelMapper mapper, Gson gson) {
        this.starRepository = starRepository;
        this.constellationRepository = constellationRepository;
        this.astronomerRepository = astronomerRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return starRepository.count() > 0;
    }

    @Override
    public String readStarsFileContent() throws IOException {
        return Files.readString(Path.of(INPUT_FILE_PATH + STARS_FILE_PATH));
    }

    @Override
    public String importStars() throws IOException {
        StringBuilder sb = new StringBuilder();

        StarSeedDTO[] starSeedDTO = gson.fromJson(
                new FileReader(INPUT_FILE_PATH + STARS_FILE_PATH), StarSeedDTO[].class);

        for (StarSeedDTO seedDTO : starSeedDTO) {
            Optional<Star> optional = starRepository.findByName(seedDTO.getName());

            if (!validatorUtil.isValid(seedDTO) || optional.isPresent()) {
                sb.append("Invalid star\n");
                continue;
            }

            Star star = mapper.map(seedDTO, Star.class);
            star.setConstellation(constellationRepository.findById(seedDTO.getConstellation()).get());

            starRepository.save(star);
            sb.append(String.format("Successfully imported star %s - %.2f light years%n", star.getName(), star.getLightYears()));
        }
        return sb.toString();
    }

    @Override
    public String exportStars() {
        StringBuilder sb = new StringBuilder();

        for (Star star : starRepository.findAllByStarTypeAndObserversIsEmpty()) {
            sb.append(String.format("Star: %s\n" +
                    "   *Distance: %.2f light years\n" +
                    "   **Description: %s\n" +
                    "   ***Constellation: %s\n",
                    star.getName(), star.getLightYears(), star.getDescription(), star.getConstellation().getName()));
        }

        return sb.toString();
    }
}
