package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.VolcanoSeedDTO;
import softuni.exam.models.entity.Volcano;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.VolcanoRepository;
import softuni.exam.repository.VolcanologistRepository;
import softuni.exam.service.VolcanoService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;

@Service
public class VolcanoServiceImpl implements VolcanoService {
    private static final String VOLCANOES_FILE_PATH = "src/main/resources/files/json/volcanoes.json";
    private final VolcanoRepository volcanoRepository;
    private final CountryRepository countryRepository;
    private final VolcanologistRepository volcanologistRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper mapper;

    public VolcanoServiceImpl(VolcanoRepository volcanoRepository, CountryRepository countryRepository, VolcanologistRepository volcanologistRepository, Gson gson, ValidationUtil validationUtil, ModelMapper mapper) {
        this.volcanoRepository = volcanoRepository;
        this.countryRepository = countryRepository;
        this.volcanologistRepository = volcanologistRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.mapper = mapper;
    }

    @Override
    public boolean areImported() {
        return volcanoRepository.count() > 0;
    }

    @Override
    public String readVolcanoesFileContent() throws IOException {
        return Files.readString(Path.of(VOLCANOES_FILE_PATH));
    }

    @Override
    public String importVolcanoes() throws IOException {
        StringBuilder sb = new StringBuilder();

        VolcanoSeedDTO[] volcanoSeedDTOS = gson.fromJson(readVolcanoesFileContent(), VolcanoSeedDTO[].class);

        for (VolcanoSeedDTO seedDTO : volcanoSeedDTOS) {
            Optional<Volcano> optional = volcanoRepository.findByName(seedDTO.getName());

            if(!validationUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid volcano");
                sb.append(System.lineSeparator());
                continue;
            }

            Volcano volcano = mapper.map(seedDTO, Volcano.class);
            volcano.setCountry(countryRepository.findById(seedDTO.getCountry()).get());
            volcano.setVolcanologists(volcanologistRepository.findAllByVolcano_Name(volcano.getName()));

            volcanoRepository.save(volcano);

            sb.append(String.format("Successfully imported volcano %s of type %s%n",volcano.getName(), volcano.getVolcanoType()));
        }


        return sb.toString();
    }

    @Override
    public String exportVolcanoes() {
        StringBuilder sb = new StringBuilder();

        Set<Volcano> volcanoSet = volcanoRepository.findAllByElevationAfterAndLastEruptionIsNotNullOrderByElevationDesc(3000);
        for (Volcano volcano : volcanoSet) {
            sb.append(String.format("Volcano: %s\n" +
                    "   *Located in: %s\n" +
                    "   **Elevation: %d\n" +
                    "   ***Last eruption on: %s\n", volcano.getName(),
                    volcano.getCountry().getName(), volcano.getElevation(), volcano.getLastEruption()));
        }

        return sb.toString();
    }
}