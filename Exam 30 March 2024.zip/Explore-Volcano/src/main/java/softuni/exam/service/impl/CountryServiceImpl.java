package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.CountrySeedDTO;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.VolcanoRepository;
import softuni.exam.service.CountryService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {
    private final CountryRepository countryRepository;
    private final Gson gson;
    private final ValidationUtil validationUtil;
    private final ModelMapper mapper;
    private final VolcanoRepository volcanoRepository;
    private static final String COUNTRIES_FILE_PATH = "src/main/resources/files/json/countries.json";

    public CountryServiceImpl(CountryRepository countryRepository, Gson gson, ValidationUtil validationUtil, ModelMapper mapper, VolcanoRepository volcanoRepository) {
        this.countryRepository = countryRepository;
        this.gson = gson;
        this.validationUtil = validationUtil;
        this.mapper = mapper;
        this.volcanoRepository = volcanoRepository;
    }

    @Override
    public boolean areImported() {
        return countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFromFile() throws IOException {
        return Files.readString(Path.of(COUNTRIES_FILE_PATH));
    }

    @Override
    public String importCountries() throws IOException {
        StringBuilder sb = new StringBuilder();

        CountrySeedDTO[] countrySeedDTOS = gson.fromJson(readCountriesFromFile(), CountrySeedDTO[].class);

        for (CountrySeedDTO seedDTO : countrySeedDTOS) {
            Optional<Country> optional = countryRepository.findByName(seedDTO.getName());

            if(!validationUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid country");
                sb.append(System.lineSeparator());
                continue;
            }

            Country country = mapper.map(seedDTO, Country.class);
            country.setVolcanoes(volcanoRepository.findAllByCountry_Name(country.getName()));

            countryRepository.save(country);

            sb.append(String.format("Successfully imported country %s - %s%n", country.getName(), country.getCapital()));
        }

        return sb.toString();
    }
}
