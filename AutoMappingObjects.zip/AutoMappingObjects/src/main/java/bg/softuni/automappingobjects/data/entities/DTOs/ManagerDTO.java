package bg.softuni.automappingobjects.data.entities.DTOs;

import java.io.BufferedReader;
import java.util.List;
import java.util.stream.Collectors;

public class ManagerDTO {
    private String firstName;
    private String lastName;
    private List<EmployeeDTO> employeeList;

    public ManagerDTO() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public List<EmployeeDTO> getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(List<EmployeeDTO> employeeList) {
        this.employeeList = employeeList;
    }

    @Override
    public String toString() {
        String stringOfEmployees = employeeList
                .stream()
                .map(e -> e.toString())
                .collect(Collectors.joining("\n"));
        return String.format("%s | %s Employees: %d%n%s", firstName, lastName, employeeList.size(), stringOfEmployees);
    }
}
