package bg.softuni.automappingobjects.services.impl;

import bg.softuni.automappingobjects.data.entities.DTOs.EmployeeSecondDTO;
import bg.softuni.automappingobjects.data.entities.Employee;
import bg.softuni.automappingobjects.data.repositories.EmployeeRepository;
import bg.softuni.automappingobjects.services.EmployeeService;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    private final EmployeeRepository employeeRepository;
    public EmployeeServiceImpl (EmployeeRepository employeeRepository, EmployeeRepository employeeRepository1) {
        this.employeeRepository = employeeRepository1;
    }
    @Override
    public List<EmployeeSecondDTO> getAllEmployeesBirthdayBefore(int year) {
        LocalDate beforeYear = LocalDate.of(year, 1, 1);

        return this.employeeRepository.findAllEmployeesAfterGivenDate(beforeYear);
    }
}
