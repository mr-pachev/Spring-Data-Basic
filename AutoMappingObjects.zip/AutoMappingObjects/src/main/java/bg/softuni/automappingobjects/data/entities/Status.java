package bg.softuni.automappingobjects.data.entities;

public enum Status {
    ON_WORK, SICK, ON_VACATION;
}
