package bg.softuni.automappingobjects.data.repositories;

import bg.softuni.automappingobjects.data.entities.DTOs.EmployeeSecondDTO;
import bg.softuni.automappingobjects.data.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    @Query("SELECT new bg.softuni.automappingobjects.data.entities.DTOs.EmployeeSecondDTO(e.firstName, e.lastName, e.salary, e.lastName) FROM Employee e WHERE e.birthday < :date")
List<EmployeeSecondDTO> findAllEmployeesAfterGivenDate(LocalDate date);
}
