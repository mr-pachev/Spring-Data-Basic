package bg.softuni.automappingobjects.services;

import bg.softuni.automappingobjects.data.entities.DTOs.EmployeeSecondDTO;
import bg.softuni.automappingobjects.data.entities.Employee;

import java.time.LocalDate;
import java.util.List;

public interface EmployeeService {
    List<EmployeeSecondDTO> getAllEmployeesBirthdayBefore(int year);
}
