package bg.softuni.automappingobjects;
import bg.softuni.automappingobjects.data.entities.Address;
import bg.softuni.automappingobjects.data.entities.DTOs.EmployeeDTO;
import bg.softuni.automappingobjects.data.entities.DTOs.EmployeeSecondDTO;
import bg.softuni.automappingobjects.data.entities.DTOs.ManagerDTO;
import bg.softuni.automappingobjects.data.entities.Employee;
import bg.softuni.automappingobjects.data.entities.Status;
import bg.softuni.automappingobjects.services.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.EmptyStackException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class MainMapping implements CommandLineRunner {
    private final EmployeeService employeeService;

    public MainMapping(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @Override
    public void run(String... args) throws Exception {

        ModelMapper modelMapper = new ModelMapper();
        Address address = new Address("Sofia", "Vakarel", 12);
        Employee manager = new Employee("Bai", "Hoi", LocalDate.now(), BigDecimal.ONE, Status.SICK, address, null, List.of());
        Employee employeeOne = new Employee("Ivan", "Pachev", LocalDate.now(), BigDecimal.TEN, Status.ON_WORK, address, manager, List.of());
        Employee employeeTwo = new Employee("Dragan", "Draganov", LocalDate.now(), BigDecimal.ONE, Status.ON_VACATION, address, manager, List.of());
        List<Employee> employeeList = List.of(employeeOne, employeeTwo);

        manager.setEmployeeList(List.of(employeeOne, employeeTwo));
//        EmployeeDTO employeeDTO = modelMapper.map(employeeOne, EmployeeDTO.class);
//        ManagerDTO managerDTO = modelMapper.map(manager, ManagerDTO.class);

        List<EmployeeSecondDTO> list = employeeService.getAllEmployeesBirthdayBefore(1990);
        String s =list.stream()
                .map(e -> e.toString())
                .collect(Collectors.joining("\n"));
        System.out.println(s);
    }
}
