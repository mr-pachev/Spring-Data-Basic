package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.City;

import javax.swing.text.html.Option;
import java.util.Optional;
import java.util.Set;

@Repository
public interface CityRepository extends JpaRepository<City, Long> {

    Set<City> findAllByCountry_CountryName(String countryName);
    Optional<City> findByCityName(String cityName);
    Optional<City> findById(long id);
}
