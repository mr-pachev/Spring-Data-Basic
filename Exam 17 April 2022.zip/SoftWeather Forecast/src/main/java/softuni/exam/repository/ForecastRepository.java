package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.DayOfWeek;
import softuni.exam.models.entity.Forecast;

import java.util.Optional;
import java.util.Set;

@Repository
public interface ForecastRepository extends JpaRepository<Forecast, Long> {
    Set<Forecast> findByCity_CityName(String cityName);
    Optional<Forecast> findByDayOfWeekAndCity_Id(DayOfWeek dayOfWeek, long id);

    @Query("SELECT f FROM Forecast f WHERE f.city.population < 150000 AND f.dayOfWeek = 2 ORDER BY f.maxTemperature DESC, f.id")
    Set<Forecast> findAllByDayOfWeekAndCity_Population();
}
