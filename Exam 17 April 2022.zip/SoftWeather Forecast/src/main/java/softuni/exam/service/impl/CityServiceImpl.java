package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.CitySeedDTO;
import softuni.exam.models.entity.City;
import softuni.exam.repository.CityRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.repository.ForecastRepository;
import softuni.exam.service.CityService;
import softuni.exam.util.ValidatorUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class CityServiceImpl implements CityService {
    private static final String CITIES_FILE_PATH = "src/main/resources/files/json/cities.json";
    private final CityRepository cityRepository;
    private final CountryRepository countryRepository;
    private final ForecastRepository forecastRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final Gson gson;

    public CityServiceImpl(CityRepository cityRepository, CountryRepository countryRepository, ForecastRepository forecastRepository, ValidatorUtil validatorUtil, ModelMapper mapper, Gson gson) {
        this.cityRepository = cityRepository;
        this.countryRepository = countryRepository;
        this.forecastRepository = forecastRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return cityRepository.count() > 0;
    }

    @Override
    public String readCitiesFileContent() throws IOException {
        return Files.readString(Path.of(CITIES_FILE_PATH));
    }

    @Override
    public String importCities() throws IOException {
        StringBuilder sb = new StringBuilder();

        CitySeedDTO[] citySeedDTOS = gson.fromJson(
                readCitiesFileContent(), CitySeedDTO[].class);

        for (CitySeedDTO seedDTO : citySeedDTOS) {
            Optional<City> optional = cityRepository.findByCityName(seedDTO.getCityName());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid city");
                sb.append(System.lineSeparator());
                continue;
            }

            City city = mapper.map(seedDTO, City.class);
            city.setCountry(countryRepository.findById(seedDTO.getCountry()).get());
            city.setForecasts(forecastRepository.findByCity_CityName(seedDTO.getCityName()));

            cityRepository.save(city);

            sb.append(String.format("Successfully imported city %s - %d%n", city.getCityName(), city.getPopulation()));
        }


        return sb.toString();
    }
}
