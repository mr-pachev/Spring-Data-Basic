package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.CountrySeedDTO;
import softuni.exam.models.entity.Country;
import softuni.exam.repository.CityRepository;
import softuni.exam.repository.CountryRepository;
import softuni.exam.service.CountryService;
import softuni.exam.util.ValidatorUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class CountryServiceImpl implements CountryService {
    private static final String COUNTRIES_FILE_PATH = "src/main/resources/files/json/countries.json";
    private final CountryRepository countryRepository;
    private final CityRepository cityRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final Gson gson;

    public CountryServiceImpl(CountryRepository countryRepository, CityRepository cityRepository, ValidatorUtil validatorUtil, ModelMapper mapper, Gson gson) {
        this.countryRepository = countryRepository;
        this.cityRepository = cityRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return countryRepository.count() > 0;
    }

    @Override
    public String readCountriesFromFile() throws IOException {
        return Files.readString(Path.of(COUNTRIES_FILE_PATH));
    }

    @Override
    public String importCountries() throws IOException {
        StringBuilder sb = new StringBuilder();
        CountrySeedDTO[] countrySeedDTOS = gson.fromJson(readCountriesFromFile(), CountrySeedDTO[].class);

        for (CountrySeedDTO seedDTO : countrySeedDTOS) {
            Optional<Country> optional = countryRepository.findByCountryName(seedDTO.getCountryName());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid country");
                sb.append(System.lineSeparator());
                continue;
            }

            Country country = mapper.map(seedDTO, Country.class);
            country.setCities(cityRepository.findAllByCountry_CountryName(country.getCountryName()));

            countryRepository.save(country);

            sb.append(String.format("Successfully imported country %s - %s%n", country.getCountryName(), country.getCurrency()));
        }

        return sb.toString();
    }
}
