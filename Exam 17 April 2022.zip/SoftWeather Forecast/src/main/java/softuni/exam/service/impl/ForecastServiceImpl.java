package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.ForecastRootDTO;
import softuni.exam.models.dto.xml.ForecastSeedDTO;
import softuni.exam.models.entity.Forecast;
import softuni.exam.repository.CityRepository;
import softuni.exam.repository.ForecastRepository;
import softuni.exam.service.ForecastService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;

@Service
public class ForecastServiceImpl implements ForecastService {
    private static final String FORECASTS_FILE_PATH = "src/main/resources/files/xml/forecasts.xml";
    private final ForecastRepository forecastRepository;
    private final CityRepository cityRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final XmlParser xmlParser;

    public ForecastServiceImpl(ForecastRepository forecastRepository, CityRepository cityRepository, ValidatorUtil validatorUtil, ModelMapper mapper, XmlParser xmlParser) {
        this.forecastRepository = forecastRepository;
        this.cityRepository = cityRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return forecastRepository.count() > 0;
    }

    @Override
    public String readForecastsFromFile() throws IOException {
        return Files.readString(Path.of(FORECASTS_FILE_PATH));
    }

    @Override
    public String importForecasts() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        ForecastRootDTO forecastRootDTO = xmlParser.fromFile(
                FORECASTS_FILE_PATH, ForecastRootDTO.class);

        for (ForecastSeedDTO seedDTO : forecastRootDTO.getForecastSeedDTOList()) {
            Optional<Forecast> optional = forecastRepository.findByDayOfWeekAndCity_Id(seedDTO.getDayOfWeek(), seedDTO.getCity());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent() || seedDTO.getDayOfWeek() == null){
                sb.append("Invalid forecast");
                sb.append(System.lineSeparator());
                continue;
            }

            Forecast forecast = mapper.map(seedDTO, Forecast.class);
            forecast.setCity(cityRepository.getById(seedDTO.getCity()));

            forecastRepository.save(forecast);

            sb.append(String.format("Successfully import forecast %s - %.2f%n", forecast.getDayOfWeek(), forecast.getMaxTemperature()));
        }

        return sb.toString();
    }

    @Override
    public String exportForecasts() {
        StringBuilder sb = new StringBuilder();

        Set<Forecast> forecastSet = forecastRepository.findAllByDayOfWeekAndCity_Population();

        for (Forecast forecast : forecastSet) {
            sb.append(String.format("City: %s:\n" +
                            "-min temperature: %.2f\n" +
                            "--max temperature: %.2f\n" +
                            "---sunrise: %s\n" +
                            "----sunset: %s\n",forecast.getCity().getCityName(),
                            forecast.getMinTemperature(), forecast.getMaxTemperature(),
                            forecast.getSunrise(), forecast.getSunset()
                    ));
        }

        return sb.toString();
    }
}
