package com.example.demo.services;

import java.math.BigDecimal;
import java.time.LocalDate;

public interface AccountService {
    void withdrawMoney(BigDecimal money, Long id);
    void transferMoney(BigDecimal money, Long id);
}
