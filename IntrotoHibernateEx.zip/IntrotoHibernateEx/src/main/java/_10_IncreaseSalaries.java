import entities.Employee;
import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class _10_IncreaseSalaries {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
       List<Employee> employeeList = em.createQuery("SELECT e FROM Employee e" +
                        " WHERE e.department.name IN('Engineering', 'Tool Design', 'Marketing', 'Information Services')", Employee.class).getResultList();

       List<Employee> updateList = new ArrayList<>();
        for (Employee e:employeeList){
            BigDecimal newSalary = e.getSalary().multiply(new BigDecimal(1.12));
            e.setSalary(newSalary);
            updateList.add(e);
        }

        updateList.forEach(e -> {
            System.out.printf("%s %s ($%.2f)%n", e.getFirstName(), e.getLastName(), e.getSalary());
        });

        em.getTransaction().commit();
        em.close();
    }
}
