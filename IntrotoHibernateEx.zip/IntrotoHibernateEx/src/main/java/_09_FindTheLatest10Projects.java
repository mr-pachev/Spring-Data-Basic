import entities.Project;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class _09_FindTheLatest10Projects {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU_Name");
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT p FROM Project p" +
                        " ORDER BY p.startDate DESC", Project.class)
                .setMaxResults(10);

        List<Project> projectList = query.getResultList();

        projectList = projectList.stream()
                .sorted(Comparator.comparing(Project::getName))
                .collect(Collectors.toList());

        projectList.forEach(p -> {

            System.out.printf("Project name: %s%n", p.getName());
            System.out.println("      Project Description: Research, design and development of …");
            System.out.printf("      Project Start Date:%s%n", p.getStartDate().minusHours(3).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")));
            System.out.printf("      Project End Date: %s%n", p.getEndDate());
        });
    }
}
