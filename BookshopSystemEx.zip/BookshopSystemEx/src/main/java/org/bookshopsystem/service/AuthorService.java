package org.bookshopsystem.service;

import org.bookshopsystem.data.entities.Author;
import org.springframework.data.jpa.repository.Query;

import java.io.IOException;
import java.util.List;

public interface AuthorService {
    void seedAuthors() throws IOException;

    Author getRandomAuthor();

    List<String> getAllAuthorsFirstAndLastNameForBooksBeforeDate1990();

    List<String> getAllAuthorsDescBooks();
}
