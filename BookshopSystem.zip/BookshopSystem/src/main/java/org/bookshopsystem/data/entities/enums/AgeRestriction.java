package org.bookshopsystem.data.entities.enums;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
