package org.bookshopsystem.data.entities.enums;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
