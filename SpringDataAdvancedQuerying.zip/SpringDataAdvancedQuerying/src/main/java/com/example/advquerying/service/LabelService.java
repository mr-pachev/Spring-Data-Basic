package com.example.advquerying.service;

public interface LabelService {
}
