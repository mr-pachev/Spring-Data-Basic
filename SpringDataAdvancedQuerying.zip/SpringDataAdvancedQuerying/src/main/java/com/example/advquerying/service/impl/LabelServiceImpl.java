package com.example.advquerying.service.impl;

import com.example.advquerying.service.LabelService;
import org.springframework.stereotype.Service;

@Service
public class LabelServiceImpl implements LabelService {
}
