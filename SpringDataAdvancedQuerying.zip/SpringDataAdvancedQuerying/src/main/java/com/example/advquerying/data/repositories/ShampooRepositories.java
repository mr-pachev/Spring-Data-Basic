package com.example.advquerying.data.repositories;

import com.example.advquerying.data.entities.Shampoo;
import com.example.advquerying.data.entities.enums.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface ShampooRepositories extends JpaRepository<Shampoo, Long> {
    Set<Shampoo> findAllBySizeOrderById(Size size);

    Set<Shampoo> findAllBySizeOrLabelIdOrderByPrice(Size size, long labelId);

    Set<Shampoo> findAllByPriceGreaterThanOrderByPriceDesc(BigDecimal price);

    Set<Shampoo> findAllByPriceLessThan(BigDecimal price);

    @Query("SELECT s FROM Shampoo s JOIN s.ingredients i WHERE i.name IN (:names)")
    Set<String> getAllByIngredientsNames(List<String> names);

    Set<Shampoo> findAllByIngredientsNameIn(List<String> names);

    @Query("FROM Shampoo WHERE ingredients.size < :num")
    Set<Shampoo> findAllWithIngredientsLessThan(int num);
}
