package com.example.advquerying.service;

import java.math.BigDecimal;
import java.util.List;

public interface IngredientService {
    List<String> getAllIngredientsStartsWithGivenLetter(String letter);
    List<String> getAllIngredientsByGivenNames(List<String> names);

    int deleteIngredientsByName(String name);

    int updateAllIngredient(BigDecimal percent);

    int updateAllIngredientByGivenNames(BigDecimal percent, List<String> names);
}
