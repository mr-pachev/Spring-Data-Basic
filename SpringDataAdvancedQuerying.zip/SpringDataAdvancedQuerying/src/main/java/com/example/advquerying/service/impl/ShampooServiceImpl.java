package com.example.advquerying.service.impl;

import com.example.advquerying.data.entities.Shampoo;
import com.example.advquerying.data.entities.enums.Size;
import com.example.advquerying.data.repositories.ShampooRepositories;
import com.example.advquerying.service.ShampooService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class ShampooServiceImpl implements ShampooService {
    private final ShampooRepositories shampooRepositories;

    public ShampooServiceImpl(ShampooRepositories shampooRepositories) {
        this.shampooRepositories = shampooRepositories;
    }


    @Override
    public List<String> getAllBySizeOrderById(String size) {
        Size enumSize = Size.valueOf(size.toUpperCase());
        return this.shampooRepositories.findAllBySizeOrderById(enumSize)
                .stream()
                .map(s -> String.format("%s %s %.2flv.", s.getBrand(), s.getSize(), s.getPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getAllBySizeOrLabelIdOrderByPrice(String size, long labelId) {
        Size enumSize = Size.valueOf(size.toUpperCase());
        return this.shampooRepositories.findAllBySizeOrLabelIdOrderByPrice(enumSize, labelId)
                .stream()
                .map(s -> String.format("%s %s %.2flv.",s.getBrand(), s.getSize(), s.getPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getAllByPriceGreaterThanOrderByPriceDesc(BigDecimal inputPrice) {
        return this.shampooRepositories.findAllByPriceGreaterThanOrderByPriceDesc(inputPrice)
                .stream()
                .map(s -> String.format("%s",s.getBrand(), s.getSize(), s.getPrice()))
                .collect(Collectors.toList());
    }

    @Override
    public int getAllShampooPriceLowerThan(BigDecimal price) {
        return (int) this.shampooRepositories.findAllByPriceLessThan(price)
                .stream()
                .count();
    }

    @Override
    public Set<String> getAllByIngredientsNames(List<String> names) {
        return this.shampooRepositories.findAllByIngredientsNameIn(names)
                .stream()
                .map(Shampoo::getBrand)
                .collect(Collectors.toSet());
    }

    @Override
    public List<String> getAllWithIngredientsLessThan(int number) {
        return this.shampooRepositories.findAllWithIngredientsLessThan(number)
                .stream()
                .map(Shampoo::getBrand)
                .collect(Collectors.toList());
    }
}
