package com.example.advquerying.service;

import com.example.advquerying.data.entities.Shampoo;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

public interface ShampooService {
    List<String> getAllBySizeOrderById(String size);
    List<String> getAllBySizeOrLabelIdOrderByPrice(String size, long labelId);
    List<String> getAllByPriceGreaterThanOrderByPriceDesc(BigDecimal inputPrice);
    int getAllShampooPriceLowerThan(BigDecimal price);
    Set<String> getAllByIngredientsNames(List<String> names);
    List<String> getAllWithIngredientsLessThan(int number);
}
