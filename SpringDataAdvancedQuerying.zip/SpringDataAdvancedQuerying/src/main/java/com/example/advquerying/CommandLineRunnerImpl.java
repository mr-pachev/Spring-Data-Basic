package com.example.advquerying;

import com.example.advquerying.service.IngredientService;
import com.example.advquerying.service.ShampooService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

@Component
public class CommandLineRunnerImpl implements CommandLineRunner {
    private final ShampooService shampooService;
    private final IngredientService ingredientService;

    public CommandLineRunnerImpl(ShampooService shampooService, IngredientService ingredientService) {
        this.shampooService = shampooService;
        this.ingredientService = ingredientService;
    }

    @Override
    public void run(String... args) throws Exception {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

//        this.shampooService.ggetAllBySizeOrderById(bufferedReader.readLine())
//                .forEach(System.out::println);

//        String inputSize = bufferedReader.readLine();
//        long inputLabelId = Integer.parseInt(bufferedReader.readLine());
//        this.shampooService.getAllBySizeOrLabelIdOrderByPrice(inputSize, inputLabelId)
//                .forEach(System.out::println);

//        this.shampooService.getAllByPriceGreaterThanOrderByPriceDesc(BigDecimal.valueOf(Double.parseDouble(bufferedReader.readLine())))
//                .forEach(System.out::println);

//        this.ingredientService.getAllIngredientsStartsWithGivenLetter(bufferedReader.readLine())
//                .forEach(System.out::println);

//        List<String> inputIngredients = new ArrayList<>();
//        String input = bufferedReader.readLine();
//        while (!input.isEmpty()) {
//            inputIngredients.add(input);
//            input = bufferedReader.readLine();
//        }
//        this.ingredientService.getAllIngredientsByGivenNames(inputIngredients)
//                .forEach(System.out::println);

//        BigDecimal value = new BigDecimal(bufferedReader.readLine());
//        int result = this.shampooService.getAllShampooPriceLowerThan(value);
//        System.out.println(result);

//        List<String> inputIngredients = new ArrayList<>();
//        String input = bufferedReader.readLine();
//        while (!input.isEmpty()) {
//            inputIngredients.add(input);
//            input = bufferedReader.readLine();
//        }
//        this.shampooService.getAllByIngredientsNames(inputIngredients)
//                .forEach(System.out::println);

//        this.shampooService.getAllWithIngredientsLessThan(Integer.parseInt(bufferedReader.readLine()))
//                .forEach(System.out::println);

//        this.ingredientService.deleteIngredientsByName(bufferedReader.readLine());

//        BigDecimal percent = new BigDecimal(bufferedReader.readLine());
//        this.ingredientService.updateAllIngredient(percent);

        BigDecimal percent = new BigDecimal(bufferedReader.readLine());
        List<String> inputIngredientNames = new ArrayList<>();
        String input = bufferedReader.readLine();
        while (!input.isEmpty()) {
            inputIngredientNames.add(input);
            input = bufferedReader.readLine();
        }
        this.ingredientService.updateAllIngredientByGivenNames(percent, inputIngredientNames);
    }
}
