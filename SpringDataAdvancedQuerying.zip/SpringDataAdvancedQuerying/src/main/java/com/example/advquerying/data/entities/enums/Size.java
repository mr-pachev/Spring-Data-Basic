package com.example.advquerying.data.entities.enums;
public enum Size {
    SMALL, MEDIUM, LARGE;
}
