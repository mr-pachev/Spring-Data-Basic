package com.example.advquerying.data.repositories;

import com.example.advquerying.data.entities.Ingredient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

@Repository
public interface IngredientRepositories extends JpaRepository<Ingredient, Long> {
    Set<Ingredient> findAllByNameStartsWith(String startWith);
    Set<Ingredient> findAllByNameInOrderByPrice(List<String> names);
    @Transactional
    @Modifying
    @Query("DELETE Ingredient WHERE name = :inputName")
    int deleteByName(String inputName);

    @Transactional
    @Modifying
    @Query("UPDATE Ingredient SET price = price * :percent")
    int updateAllIngredient(BigDecimal percent);

    @Transactional
    @Modifying
    @Query("UPDATE Ingredient  SET price = price * :percent WHERE name IN (:names)")
    int updateAllIngredientByGivenNames(BigDecimal percent, List<String> names);
}
