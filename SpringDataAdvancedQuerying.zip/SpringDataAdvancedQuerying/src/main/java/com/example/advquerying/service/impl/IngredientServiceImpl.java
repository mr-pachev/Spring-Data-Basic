package com.example.advquerying.service.impl;

import com.example.advquerying.data.entities.Ingredient;
import com.example.advquerying.data.repositories.IngredientRepositories;
import com.example.advquerying.service.IngredientService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class IngredientServiceImpl implements IngredientService {
    private final IngredientRepositories ingredientRepositories;

    public IngredientServiceImpl(IngredientRepositories ingredientRepositories) {
        this.ingredientRepositories = ingredientRepositories;
    }

    @Override
    public List<String> getAllIngredientsStartsWithGivenLetter(String letter) {
        return this.ingredientRepositories.findAllByNameStartsWith(letter)
                .stream()
                .map(Ingredient::getName)
                .collect(Collectors.toList());
    }

    @Override
    public List<String> getAllIngredientsByGivenNames(List<String> names) {
        return this.ingredientRepositories.findAllByNameInOrderByPrice(names)
                .stream()
                .map(Ingredient::getName)
                .collect(Collectors.toList());
    }

    @Override
    public int deleteIngredientsByName(String name) {
        return this.ingredientRepositories.deleteByName(name);
    }

    @Override
    public int updateAllIngredient(BigDecimal percent) {
        return this.ingredientRepositories.updateAllIngredient(percent);
    }

    @Override
    public int updateAllIngredientByGivenNames(BigDecimal percent, List<String> names) {
        return this.ingredientRepositories.updateAllIngredientByGivenNames(percent, names);
    }

}
