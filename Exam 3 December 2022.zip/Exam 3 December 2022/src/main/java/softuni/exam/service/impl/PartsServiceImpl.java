package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.PartSeedDTO;
import softuni.exam.models.entity.Part;
import softuni.exam.repository.PartsRepository;
import softuni.exam.repository.TasksRepository;
import softuni.exam.service.PartsService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class PartsServiceImpl implements PartsService {
    private final PartsRepository partsRepository;
    private final TasksRepository tasksRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final Gson gson;
    private static String PARTS_FILE_PATH = "src/main/resources/files/json/parts.json";

    public PartsServiceImpl(PartsRepository partsRepository, TasksRepository tasksRepository, ValidatorUtil validatorUtil, ModelMapper mapper, Gson gson) {
        this.partsRepository = partsRepository;
        this.tasksRepository = tasksRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return partsRepository.count() > 0;
    }

    @Override
    public String readPartsFileContent() throws IOException {
        return Files.readString(Path.of(PARTS_FILE_PATH));
    }

    @Override
    public String importParts() throws IOException {
        StringBuilder sb = new StringBuilder();

        PartSeedDTO[] partSeedDTOS = this.gson.fromJson(
                new FileReader(PARTS_FILE_PATH), PartSeedDTO[].class);

        for (PartSeedDTO partSeedDTO : partSeedDTOS) {
            Optional<Part> optional = partsRepository.findByPartName(partSeedDTO.getPartName());

            if(!validatorUtil.isValid(partSeedDTO) || optional.isPresent()){
                sb.append("Invalid part");
                sb.append(System.lineSeparator());
                continue;
            }

            Part part = mapper.map(partSeedDTO, Part.class);
            part.setTasks(tasksRepository.findAllByPart_PartName(part.getPartName()));

            partsRepository.save(part);

            sb.append(String.format("Successfully imported part %s - %.2f%n", part.getPartName(), part.getPrice()));
        }

        return sb.toString();
    }
}
