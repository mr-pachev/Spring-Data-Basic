package softuni.exam.models.dto.xml;

import javax.validation.constraints.Positive;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.math.BigDecimal;

@XmlRootElement(name = "task")
@XmlAccessorType(XmlAccessType.FIELD)
public class TaskSeedDTO {
    @XmlElement
    private String date;
    @XmlElement
    private BigDecimal price;
    @XmlElement(name = "car")
    private CarIdDTO carIdDTO;
    @XmlElement(name = "mechanic")
    private MechanicFirstNameDTO mechanicFirstNameDTO;
    @XmlElement(name = "part")
    private PartIdDTO partIdDTO;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    @Positive
    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public CarIdDTO getCarDTO() {
        return carIdDTO;
    }

    public void setCarDTO(CarIdDTO carIdDTO) {
        this.carIdDTO = carIdDTO;
    }

    public MechanicFirstNameDTO getMechanicDTO() {
        return mechanicFirstNameDTO;
    }

    public void setMechanicDTO(MechanicFirstNameDTO mechanicFirstNameDTO) {
        this.mechanicFirstNameDTO = mechanicFirstNameDTO;
    }

    public PartIdDTO getPartDTO() {
        return partIdDTO;
    }

    public void setPartDTO(PartIdDTO partIdDTO) {
        this.partIdDTO = partIdDTO;
    }
}
