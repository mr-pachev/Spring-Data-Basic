package softuni.exam.models.dto.xml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "tasks")
@XmlAccessorType(XmlAccessType.FIELD)
public class TaskRootDTO {
    @XmlElement(name = "task")
    private List<TaskSeedDTO> taskSeedDTOList;

    public List<TaskSeedDTO> getTaskSeedDTOList() {
        return taskSeedDTOList;
    }

    public void setTaskSeedDTOList(List<TaskSeedDTO> taskSeedDTOList) {
        this.taskSeedDTOList = taskSeedDTOList;
    }
}
