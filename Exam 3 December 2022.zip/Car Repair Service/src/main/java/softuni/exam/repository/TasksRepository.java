package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.CarType;
import softuni.exam.models.entity.Task;

import java.util.Set;

@Repository
public interface TasksRepository extends JpaRepository<Task, Long> {
    Set<Task> findAllByPart_PartName(String name);
    Set<Task> findAllByMechanic_FirstName(String name);
    Set<Task> findAllByCar_PlateNumber(String number);

    Set<Task> findAllByCar_CarTypeOrderByPriceDesc(CarType coupe);
}
