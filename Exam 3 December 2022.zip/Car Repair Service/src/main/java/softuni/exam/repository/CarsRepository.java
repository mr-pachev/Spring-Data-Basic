package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Car;
import softuni.exam.models.entity.CarType;

import java.util.Optional;
import java.util.Set;

@Repository
public interface CarsRepository extends JpaRepository<Car, Long> {
    Optional<Car> findByPlateNumber(String number);
    Optional<Car> findById(long id);
}
