package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.TaskRootDTO;
import softuni.exam.models.dto.xml.TaskSeedDTO;
import softuni.exam.models.entity.CarType;
import softuni.exam.models.entity.Mechanic;
import softuni.exam.models.entity.Task;
import softuni.exam.repository.CarsRepository;
import softuni.exam.repository.MechanicsRepository;
import softuni.exam.repository.PartsRepository;
import softuni.exam.repository.TasksRepository;
import softuni.exam.service.TasksService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.Set;

@Service
public class TasksServiceImpl implements TasksService {
    private final TasksRepository tasksRepository;
    private final MechanicsRepository mechanicsRepository;
    private final CarsRepository carsRepository;
    private final PartsRepository partsRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final XmlParser xmlParser;
    private static String TASKS_FILE_PATH = "src/main/resources/files/xml/tasks.xml";

    public TasksServiceImpl(TasksRepository tasksRepository, MechanicsRepository mechanicsRepository, CarsRepository carsRepository, PartsRepository partsRepository, ValidatorUtil validatorUtil, ModelMapper mapper, XmlParser xmlParser) {
        this.tasksRepository = tasksRepository;
        this.mechanicsRepository = mechanicsRepository;
        this.carsRepository = carsRepository;
        this.partsRepository = partsRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return tasksRepository.count() > 0;
    }

    @Override
    public String readTasksFileContent() throws IOException {
        return Files.readString(Path.of(TASKS_FILE_PATH));
    }

    @Override
    public String importTasks() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        TaskRootDTO taskRootDTO = xmlParser.fromFile(TASKS_FILE_PATH, TaskRootDTO.class);

        for (TaskSeedDTO seedDTO : taskRootDTO.getTaskSeedDTOList()) {
            Optional<Mechanic> optional = mechanicsRepository.findByFirstName(seedDTO.getMechanicDTO().getFirstName());

            if(!validatorUtil.isValid(seedDTO) || optional.isEmpty()){
                sb.append("Invalid task");
                sb.append(System.lineSeparator());
                continue;
            }

            Task task = mapper.map(seedDTO, Task.class);
            task.setCar(carsRepository.findById(seedDTO.getCarDTO().getId()).get());
            task.setPart(partsRepository.findById(seedDTO.getPartDTO().getId()).get());
            task.setMechanic(mechanicsRepository.findByFirstName(seedDTO.getMechanicDTO().getFirstName()).get());

            tasksRepository.save(task);

            sb.append(String.format("Successfully imported task %.2f%n", task.getPrice()));
        }

        return sb.toString();
    }

    @Override
    public String getCoupeCarTasksOrderByPrice() {
        StringBuilder sb = new StringBuilder();

        Set<Task> taskList = tasksRepository.findAllByCar_CarTypeOrderByPriceDesc(CarType.coupe);

        for (Task task : taskList) {
            sb.append(String.format("Car %s %s with %dkm\n" +
                                    "-Mechanic: %s %s - task №%d:\n" +
                                    " --Engine: %.1f\n" +
                                    "---Price: %s$\n", task.getCar().getCarMake(),
                    task.getCar().getCarModel(), task.getCar().getKilometers(),
                    task.getMechanic().getFirstName(), task.getMechanic().getLastName(),
                    task.getId(), task.getCar().getEngine(), task.getPrice()));
        }


        return sb.toString();
    }
}
