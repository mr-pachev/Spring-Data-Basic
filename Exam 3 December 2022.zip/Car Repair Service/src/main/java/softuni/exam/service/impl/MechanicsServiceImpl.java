package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.MechanicSeedDTO;
import softuni.exam.models.entity.Mechanic;
import softuni.exam.repository.MechanicsRepository;
import softuni.exam.repository.TasksRepository;
import softuni.exam.service.MechanicsService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class MechanicsServiceImpl implements MechanicsService {
    private final MechanicsRepository mechanicsRepository;
    private final TasksRepository tasksRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
    private final Gson gson;
    private static String MECHANICS_FILE_PATH = "src/main/resources/files/json/mechanics.json";

    public MechanicsServiceImpl(MechanicsRepository mechanicsRepository, TasksRepository tasksRepository, ModelMapper mapper, ValidatorUtil validatorUtil, Gson gson) {
        this.mechanicsRepository = mechanicsRepository;
        this.tasksRepository = tasksRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return mechanicsRepository.count() > 0;
    }

    @Override
    public String readMechanicsFromFile() throws IOException {
        return Files.readString(Path.of(MECHANICS_FILE_PATH));
    }

    @Override
    public String importMechanics() throws IOException {
        StringBuilder sb = new StringBuilder();

        MechanicSeedDTO[] mechanicSeedDTOS = this.gson.fromJson(
                readMechanicsFromFile(), MechanicSeedDTO[].class);

        for (MechanicSeedDTO seedDTO : mechanicSeedDTOS) {
            Optional<Mechanic> optional = mechanicsRepository.findByEmail(seedDTO.getEmail());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid mechanic");
                sb.append(System.lineSeparator());
                continue;
            }

            Mechanic mechanic = mapper.map(seedDTO, Mechanic.class);
            mechanic.setTasks(tasksRepository.findAllByMechanic_FirstName(seedDTO.getFirstName()));

            mechanicsRepository.save(mechanic);

            sb.append(String.format("Successfully imported mechanic %s %s%n", mechanic.getFirstName(), mechanic.getLastName()));
        }

        return sb.toString();
    }
}
