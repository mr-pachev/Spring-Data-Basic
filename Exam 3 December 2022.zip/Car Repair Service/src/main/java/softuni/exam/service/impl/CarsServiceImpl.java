package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.CarRootDTO;
import softuni.exam.models.dto.xml.CarSeedDTO;
import softuni.exam.models.entity.Car;
import softuni.exam.repository.CarsRepository;
import softuni.exam.repository.TasksRepository;
import softuni.exam.service.CarsService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class CarsServiceImpl implements CarsService {
    private final CarsRepository carsRepository;
    private final TasksRepository tasksRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
    private final XmlParser xmlParser;
    private static String CARS_FILE_PATH = "src/main/resources/files/xml/cars.xml";

    public CarsServiceImpl(CarsRepository carsRepository, TasksRepository tasksRepository, ModelMapper mapper, ValidatorUtil validatorUtil, XmlParser xmlParser) {
        this.carsRepository = carsRepository;
        this.tasksRepository = tasksRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return carsRepository.count() > 0;
    }

    @Override
    public String readCarsFromFile() throws IOException {
        return Files.readString(Path.of(CARS_FILE_PATH));
    }

    @Override
    public String importCars() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        CarRootDTO carRootDTO = xmlParser.fromFile(CARS_FILE_PATH, CarRootDTO.class);

        for (CarSeedDTO seedDTO : carRootDTO.getCarSeedDTOList()) {
            Optional<Car> optional = carsRepository.findByPlateNumber(seedDTO.getPlateNumber());

            if(!validatorUtil.isValid(seedDTO) || optional.isPresent()){
                sb.append("Invalid car");
                sb.append(System.lineSeparator());
                continue;
            }

            Car car = mapper.map(seedDTO, Car.class);
            car.setTasks(tasksRepository.findAllByCar_PlateNumber(car.getPlateNumber()));

            carsRepository.save(car);

            sb.append(String.format("Successfully imported car %s - %s%n", car.getCarMake(), car.getCarModel()));
        }

        return sb.toString();
    }
}
