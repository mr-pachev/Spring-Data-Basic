package bg.productsshop.model.DTOs;

import com.google.gson.annotations.Expose;
import jakarta.validation.constraints.Size;

public class ImportCategoryDTO {
    @Expose
    private String name;

    public ImportCategoryDTO() {
    }

    @Size(min = 3, max = 15)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
