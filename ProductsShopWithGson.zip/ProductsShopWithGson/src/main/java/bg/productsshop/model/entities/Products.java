package bg.productsshop.model.entities;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Set;

@Entity
@Table(name = "products")
public class Products extends BaseEntity{
    @Column
    private String name;
    @Column
    private BigDecimal price;

    @ManyToOne
    private User buyer;
    @ManyToOne
    private User seller;

    @ManyToMany
    private Set<Categories> categories;

    public Products() {
    }

    public Products(String name, BigDecimal price, User buyer, User seller) {
        this.name = name;
        this.price = price;
        this.buyer = buyer;
        this.seller = seller;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public User getBuyer() {
        return buyer;
    }

    public void setBuyer(User buyer) {
        this.buyer = buyer;
    }

    public User getSeller() {
        return seller;
    }

    public void setSeller(User seller) {
        this.seller = seller;
    }

    public Set<Categories> getCategories() {
        return categories;
    }

    public void setCategories(Set<Categories> categories) {
        this.categories = categories;
    }
}
