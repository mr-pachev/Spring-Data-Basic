package bg.productsshop.repository;

import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.entities.Categories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CategoryRepository extends JpaRepository<Categories, Long> {
    @Query("FROM Categories c ORDER BY SIZE(c.products)")
    List<Categories> getAllCategories();
}

