package bg.productsshop;

import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.DTOs.UserSoldDTO;
import bg.productsshop.model.DTOs.ProductNamePriceSellerDTO;
import bg.productsshop.service.CategoryService;
import bg.productsshop.service.ProductService;
import bg.productsshop.service.UserService;
import com.google.gson.Gson;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

@Component
public class CommandLineRunner implements org.springframework.boot.CommandLineRunner {
    private static final String OUT_PATH = "src/main/resources/files/out/";
    private static final String PRODUCT_IN_RANGE = "products-in-range.json";
    private static final String SOLD_PRODUCT = "sold-product.json";

    public static final String CATEGORIES_BY_PRODUCTS = "categories-by-products.json";
    private final UserService userService;
    private final CategoryService categoryService;
    private final ProductService productService;
    private final BufferedReader bufferedReader;
    private final Gson gson;

    public CommandLineRunner(UserService userService, CategoryService categoryService, ProductService productService, Gson gson) {
        this.userService = userService;
        this.categoryService = categoryService;
        this.productService = productService;
        this.gson = gson;
        bufferedReader = new BufferedReader(new InputStreamReader(System.in));
    }

    @Override
    public void run(String... args) throws Exception {
        seedData();
        System.out.println("Enter number of exercise:");

        int exNum = Integer.parseInt(bufferedReader.readLine());

        switch (exNum){
            case 1 -> productsInRange();
            case 2 -> userWithSoldProducts();
            case 3 -> allProducts();
        }
    }

    private void allProducts() throws IOException {
        List<CategoryStatsDTO> categoryStatsDTOS = categoryService
                .getAllProducts();

        String content = gson.toJson(categoryStatsDTOS);

        writeToJSON(OUT_PATH + CATEGORIES_BY_PRODUCTS, content);
    }

    private void userWithSoldProducts() throws IOException {
        List<UserSoldDTO> userSoldDTOS = userService
                .findAllSoldProducts();

        String content = gson.toJson(userSoldDTOS);
        writeToJSON(OUT_PATH + SOLD_PRODUCT, content);
    }


    private void productsInRange() throws IOException {
        List<ProductNamePriceSellerDTO> productNamePriceSellerDTOS = productService
                .getProductsInRange(BigDecimal.valueOf(500L), BigDecimal.valueOf(1000L));

        String content = gson.toJson(productNamePriceSellerDTOS);

        writeToJSON(OUT_PATH + PRODUCT_IN_RANGE, content);
    }

    private void writeToJSON(String filePath, String content) throws IOException {
        Files
                .write(Path.of(filePath), Collections.singleton(content));
    }

    private void seedData() throws IOException {
        userService.seedUsers();
        categoryService.seedCategories();
        productService.seedProducts();
    }
}
