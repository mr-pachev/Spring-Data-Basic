package bg.productsshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsShopApplication.class, args);
	}

}
