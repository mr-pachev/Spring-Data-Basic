package bg.productsshop.service;

import bg.productsshop.model.DTOs.UserSoldDTO;
import bg.productsshop.model.entities.User;

import java.io.IOException;
import java.util.List;

public interface UserService {
    void seedUsers() throws IOException;
    User finaRandomUser();

    List<UserSoldDTO> findAllSoldProducts();
}
