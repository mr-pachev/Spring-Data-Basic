package bg.productsshop.service;

import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.DTOs.ProductNamePriceSellerDTO;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

public interface ProductService {
    void seedProducts() throws IOException;

    List<ProductNamePriceSellerDTO> getProductsInRange(BigDecimal startRange, BigDecimal endRange);


}
