package bg.productsshop.service.impl;

import bg.productsshop.consts.GlobalConstants;
import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.DTOs.ImportProductDTO;
import bg.productsshop.model.DTOs.ProductNamePriceSellerDTO;
import bg.productsshop.model.entities.Products;
import bg.productsshop.repository.ProductRepository;
import bg.productsshop.service.CategoryService;
import bg.productsshop.service.ProductService;
import bg.productsshop.service.UserService;
import bg.productsshop.util.ValidatorUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {
    public static final String PRODUCTS_FILE_NAME = "products.json";
    private final ProductRepository productRepository;
    private final UserService userService;
    private final CategoryService categoryService;
    private final ValidatorUtil validatorUtil;
    private final Gson gson;
    private final ModelMapper mapper;

    public ProductServiceImpl(ProductRepository productRepository, UserService userService, CategoryService categoryService, ValidatorUtil validatorUtil, Gson gson, ModelMapper mapper) {
        this.productRepository = productRepository;
        this.userService = userService;
        this.categoryService = categoryService;
        this.validatorUtil = validatorUtil;
        this.gson = gson;
        this.mapper = mapper;
    }

    @Override
    public void seedProducts() throws IOException {
        if(productRepository.count() > 0){
            return;
        }
        //четем JSON файла
        String content = Files.readString(Path.of(GlobalConstants.FILES_PATH + PRODUCTS_FILE_NAME));

        ImportProductDTO[] importProductDTOS = gson
                .fromJson(content, ImportProductDTO[].class);

        Arrays.stream(importProductDTOS)
                .filter(validatorUtil::isValid)
                .map(ImportProductDTO -> {
                    Products products = mapper.map(ImportProductDTO, Products.class);

                    products.setSeller(userService.finaRandomUser());

                    //ако цената е по-малка от 500 ще има купувач
                    if(products.getPrice().compareTo(BigDecimal.valueOf(700L)) > 0){
                        products.setBuyer(userService.finaRandomUser());
                    }

                    products.setCategories(categoryService.findRandomCategories());
                    return products;
                })
                .forEach(productRepository::save);
    }

    @Override
    public List<ProductNamePriceSellerDTO> getProductsInRange(BigDecimal startRange, BigDecimal endRange) {
        return productRepository
                .getProductsByPriceBetweenWhereBuyerIsNull(startRange, endRange)
                .stream()
                .map(products -> {
                    ProductNamePriceSellerDTO productNamePriceSellerDTO = mapper.map(products, ProductNamePriceSellerDTO.class);
                    productNamePriceSellerDTO.setSeller(String.format("%s %s", products.getSeller().getFirstName(), products.getSeller().getLastName()));

                    return productNamePriceSellerDTO;
                })
                .collect(Collectors.toList());
    }
}
