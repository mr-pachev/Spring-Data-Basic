package bg.productsshop.service.impl;

import bg.productsshop.consts.GlobalConstants;
import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.DTOs.ImportCategoryDTO;
import bg.productsshop.model.entities.Categories;
import bg.productsshop.model.entities.Products;
import bg.productsshop.repository.CategoryRepository;
import bg.productsshop.service.CategoryService;
import bg.productsshop.util.ValidatorUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    private static final String CATEGORY_FILE_NAME = "categories.json";
    private final Gson gson;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;
    private final CategoryRepository categoryRepository;

    public CategoryServiceImpl(Gson gson, ValidatorUtil validatorUtil, ModelMapper mapper, CategoryRepository categoryRepository) {
        this.gson = gson;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
        this.categoryRepository = categoryRepository;
    }


    @Override
    public void seedCategories() throws IOException {
        if(categoryRepository.count() > 0){
            return;
        }
        String content = Files
                .readString(Path.of(GlobalConstants.FILES_PATH + CATEGORY_FILE_NAME));

        ImportCategoryDTO[] importCategoryDTOS = gson
                .fromJson(content, ImportCategoryDTO[].class);

        Arrays.stream(importCategoryDTOS)
                .filter(validatorUtil::isValid)
                .map(ImportCategoryDTO -> mapper.map(ImportCategoryDTO, Categories.class))
                .forEach(categoryRepository::save);
    }

    @Override
    public Set<Categories> findRandomCategories() {
        Set<Categories> categoriesSet = new HashSet<>();
        int categoriesCount = ThreadLocalRandom.current().nextInt(1, 3);    //случайно число от 1 до 2
        long totalCountCategories = categoryRepository.count();                         //броя на категориите

        for (int i = 0; i < categoriesCount; i++) {
            //взима случайно id
            long randomId = ThreadLocalRandom.current().nextLong(1, totalCountCategories + 1);

            Categories CategoryFound = categoryRepository.findById(randomId)
                    .orElse(null);

            categoriesSet.add(CategoryFound);
        };
        return categoriesSet;
    }

    @Override
    public List<CategoryStatsDTO> getAllProducts() {
        return categoryRepository
                .getAllCategories()
                .stream()
                .map(c -> {
                    CategoryStatsDTO categoryStatsDTO = mapper.map(c, CategoryStatsDTO.class);
                    categoryStatsDTO.setProductsCount(c.getProducts().size());
                    BigDecimal sum = c.getProducts().stream().map(Products::getPrice).reduce(BigDecimal::add).get();
                    categoryStatsDTO.setTotalRevenue(sum);
                    categoryStatsDTO.setAveragePrice(sum.divide(BigDecimal.valueOf(c.getProducts().size()), MathContext.DECIMAL64));

                    return categoryStatsDTO;
                })
                .collect(Collectors.toList());
    }
}
