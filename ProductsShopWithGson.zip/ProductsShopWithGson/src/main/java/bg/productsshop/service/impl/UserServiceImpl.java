package bg.productsshop.service.impl;

import bg.productsshop.consts.GlobalConstants;
import bg.productsshop.model.DTOs.ProductWithBuyerDTO;
import bg.productsshop.model.DTOs.UserSoldDTO;
import bg.productsshop.model.DTOs.ImportUserDTO;
import bg.productsshop.model.entities.Products;
import bg.productsshop.model.entities.User;
import bg.productsshop.repository.UserRepository;
import bg.productsshop.service.UserService;
import bg.productsshop.util.ValidatorUtil;
import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {
    private static final String USER_FILE_NAME = "users.json";
    private final Gson gson;
    private final UserRepository userRepository;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;

    public UserServiceImpl(Gson gson, UserRepository userRepository, ValidatorUtil validatorUtil, ModelMapper mapper) {
        this.gson = gson;
        this.userRepository = userRepository;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
    }

    @Override
    public void seedUsers() throws IOException {
        if(userRepository.count() > 0){
            return;
        }
       String content = Files
                .readString(Path.of(GlobalConstants.FILES_PATH + USER_FILE_NAME));

       ImportUserDTO[] importUserDTOS = gson.fromJson(content, ImportUserDTO[].class);

        Arrays.stream(importUserDTOS)
                .filter(validatorUtil::isValid)
                .map(importUserDTO -> mapper.map(importUserDTO, User.class))
                .forEach(userRepository::save);
    }

    @Override
    public User finaRandomUser() {
        //взима случайно id от хранилещето
        long randomId = ThreadLocalRandom
                .current().nextLong(1, userRepository.count() + 1);

        //прави заявка за user по id(случайното id)
        return userRepository
                .findById(randomId)
                .orElse(null);
    }

    @Override
    public List<UserSoldDTO> findAllSoldProducts() {
        return userRepository.findAllSoldProducts()
                .stream()
                .map(user ->  mapper.map(user, UserSoldDTO.class))
                .collect(Collectors.toList());
    }
}
