package bg.productsshop.service;

import bg.productsshop.model.DTOs.CategoryStatsDTO;
import bg.productsshop.model.entities.Categories;

import java.io.IOException;
import java.util.List;
import java.util.Set;

public interface CategoryService {
    void seedCategories() throws IOException;
    Set<Categories> findRandomCategories();

    List<CategoryStatsDTO> getAllProducts();
}
