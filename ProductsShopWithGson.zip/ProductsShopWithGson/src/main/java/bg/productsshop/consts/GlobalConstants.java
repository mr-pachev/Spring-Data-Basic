package bg.productsshop.consts;

public class GlobalConstants {
    public static final String FILES_PATH = "src/main/resources/files/";
}
