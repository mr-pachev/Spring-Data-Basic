package softuni.exam.service.impl;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.xml.BorrowingRecordSeedDTO;
import softuni.exam.models.dto.xml.BorrowingRecordsSeedRootDTO;
import softuni.exam.models.entity.Book;
import softuni.exam.models.entity.BorrowingRecord;
import softuni.exam.models.entity.Genre;
import softuni.exam.models.entity.LibraryMember;
import softuni.exam.repository.BookRepository;
import softuni.exam.repository.BorrowingRecordRepository;
import softuni.exam.repository.LibraryMemberRepository;
import softuni.exam.service.BorrowingRecordsService;
import softuni.exam.util.ValidatorUtil;
import softuni.exam.util.XmlParser;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;

@Service
public class BorrowingRecordsServiceImpl implements BorrowingRecordsService {
    private final BorrowingRecordRepository borrowingRecordRepository;
    private final BookRepository bookRepository;
    private final LibraryMemberRepository libraryMemberRepository;
    private final ModelMapper mapper;
    private final ValidatorUtil validatorUtil;
    private final XmlParser xmlParser;
    private static final String BORROWING_RECORD_PATH = "src/main/resources/files/xml/borrowing-records.xml";

    public BorrowingRecordsServiceImpl(BorrowingRecordRepository borrowingRecordRepository, BookRepository bookRepository, LibraryMemberRepository libraryMemberRepository, ModelMapper mapper, ValidatorUtil validatorUtil, XmlParser xmlParser) {
        this.borrowingRecordRepository = borrowingRecordRepository;
        this.bookRepository = bookRepository;
        this.libraryMemberRepository = libraryMemberRepository;
        this.mapper = mapper;
        this.validatorUtil = validatorUtil;
        this.xmlParser = xmlParser;
    }

    @Override
    public boolean areImported() {
        return borrowingRecordRepository.count() > 0;
    }

    @Override
    public String readBorrowingRecordsFromFile() throws IOException {
        return Files.readString(Path.of(BORROWING_RECORD_PATH));
    }

    @Override
    public String importBorrowingRecords() throws IOException, JAXBException {
        StringBuilder sb = new StringBuilder();

        BorrowingRecordsSeedRootDTO borrowingRecordsSeedRootDTO = xmlParser
                .fromFile(BORROWING_RECORD_PATH, BorrowingRecordsSeedRootDTO.class);

        for (BorrowingRecordSeedDTO borrowingRecord : borrowingRecordsSeedRootDTO.getBorrowingRecordsSeedDTO()) {
            Optional<Book> optionalBook = bookRepository.findByTitle(borrowingRecord.getBook().getTitle());
            Optional<LibraryMember> optionalLibraryMember = libraryMemberRepository.findById(borrowingRecord.getMember().getId());

            if(!validatorUtil.isValid(borrowingRecord) || optionalBook.isEmpty() || optionalLibraryMember.isEmpty()){
                sb.append("Invalid borrowing record");
                sb.append(System.lineSeparator());
                continue;
            }

            BorrowingRecord borrowingRecord1 = mapper.map(borrowingRecord, BorrowingRecord.class);
            borrowingRecord1.setBook(optionalBook.get());
            borrowingRecord1.setLibraryMember(optionalLibraryMember.get());

            borrowingRecordRepository.save(borrowingRecord1);

            sb.append(String.format("Successfully imported borrowing record %s - %s%n",
                    borrowingRecord1.getBook().getTitle(), borrowingRecord1.getBorrowDate()));
        }
        return sb.toString();
    }

    @Override
    public String exportBorrowingRecords() {
        StringBuilder sb = new StringBuilder();

        Set<BorrowingRecord> set = borrowingRecordRepository.findAllByBorrowDateBeforeAndBook_GenreOrderByBorrowDateDesc(LocalDate.parse("2021-09-10"), Genre.SCIENCE_FICTION);

        for (BorrowingRecord borrowingRecord : set) {
            sb.append(String.format("Book title: %s\n" +
                    "*Book author: %s\n" +
                    "**Date borrowed: %s\n" +
                    "***Borrowed by: %s %s\n",
                    borrowingRecord.getBook().getTitle(),
                    borrowingRecord.getBook().getAuthor(),
                    borrowingRecord.getBorrowDate(),
                    borrowingRecord.getLibraryMember().getFirstName(),
                    borrowingRecord.getLibraryMember().getLastName()
                    ));
        }

        return sb.toString();
    }
}
