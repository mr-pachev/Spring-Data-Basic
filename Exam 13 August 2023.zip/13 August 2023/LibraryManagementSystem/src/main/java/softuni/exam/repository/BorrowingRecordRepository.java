package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.BorrowingRecord;
import softuni.exam.models.entity.Genre;
import softuni.exam.models.entity.LibraryMember;

import java.time.LocalDate;
import java.util.Set;

@Repository
public interface BorrowingRecordRepository extends JpaRepository<BorrowingRecord, Long> {
    Set<BorrowingRecord> findByBookTitle(String name);
    Set<BorrowingRecord> findAllByLibraryMember_PhoneNumber(String phoneNum);
    Set<BorrowingRecord> findByLibraryMemberId(long id);

    Set<BorrowingRecord> findAllByBorrowDateBeforeAndBook_GenreOrderByBorrowDateDesc(LocalDate date, Genre SCIENCE_FICTION);
}
