package softuni.exam.models.dto.xml;

import softuni.exam.models.entity.BorrowingRecord;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;
@XmlRootElement(name = "borrowing_records")
@XmlAccessorType(XmlAccessType.FIELD)
public class BorrowingRecordsSeedRootDTO {
    @XmlElement(name = "borrowing_record")
    private List<BorrowingRecordSeedDTO> borrowingRecordsSeedDTO;

    public List<BorrowingRecordSeedDTO> getBorrowingRecordsSeedDTO() {
        return borrowingRecordsSeedDTO;
    }

    public void setBorrowingRecordsSeedDTO(List<BorrowingRecordSeedDTO> borrowingRecordsSeedDTO) {
        this.borrowingRecordsSeedDTO = borrowingRecordsSeedDTO;
    }
}
