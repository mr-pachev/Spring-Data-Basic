package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.LibraryMemberSeedDTO;
import softuni.exam.models.entity.LibraryMember;
import softuni.exam.repository.BorrowingRecordRepository;
import softuni.exam.repository.LibraryMemberRepository;
import softuni.exam.service.LibraryMemberService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class LibraryMemberServiceImpl implements LibraryMemberService {
    private static final String JSON_FILES_PATH = "src/main/resources/files/json/";
    private static final String LIBRARY_MEMBERS_FILES = "library-members.json";
    private final LibraryMemberRepository libraryMemberRepository;
    private final BorrowingRecordRepository borrowingRecordRepository;
    private final Gson gson;
    private final ValidatorUtil validatorUtil;
    private final ModelMapper mapper;

    public LibraryMemberServiceImpl(LibraryMemberRepository libraryMemberRepository, BorrowingRecordRepository borrowingRecordRepository, Gson gson, ValidatorUtil validatorUtil, ModelMapper mapper) {
        this.libraryMemberRepository = libraryMemberRepository;
        this.borrowingRecordRepository = borrowingRecordRepository;
        this.gson = gson;
        this.validatorUtil = validatorUtil;
        this.mapper = mapper;
    }

    @Override
    public boolean areImported() {
        return libraryMemberRepository.count() > 0;
    }

    @Override
    public String readLibraryMembersFileContent() throws IOException {

        return Files.readString(Path.of(JSON_FILES_PATH + LIBRARY_MEMBERS_FILES));
    }

    @Override
    public String importLibraryMembers() throws IOException {
        StringBuilder sb = new StringBuilder();

        LibraryMemberSeedDTO[] libraryMemberSeedDTOS = gson
                .fromJson(new FileReader(JSON_FILES_PATH + LIBRARY_MEMBERS_FILES), LibraryMemberSeedDTO[].class);

        for (LibraryMemberSeedDTO libraryMemberSeedDTO : libraryMemberSeedDTOS) {
            Optional<LibraryMember> optional = libraryMemberRepository.findByPhoneNumber(libraryMemberSeedDTO.getPhoneNumber());

            if(!validatorUtil.isValid(libraryMemberSeedDTO) || optional.isPresent()
                    || libraryMemberSeedDTO.getFirstName() == null){
                sb.append("Invalid library member");
                sb.append(System.lineSeparator());
                continue;
            }

            LibraryMember libraryMember = mapper.map(libraryMemberSeedDTO, LibraryMember.class);
            libraryMember.setBorrowingRecord(borrowingRecordRepository.findAllByLibraryMember_PhoneNumber(libraryMemberSeedDTO.getFirstName()));

            libraryMemberRepository.save(libraryMember);

            sb.append(String.format("Successfully imported library member %s - %s%n", libraryMember.getFirstName(),
                    libraryMember.getLastName()));
        }

        return sb.toString();
    }
}
