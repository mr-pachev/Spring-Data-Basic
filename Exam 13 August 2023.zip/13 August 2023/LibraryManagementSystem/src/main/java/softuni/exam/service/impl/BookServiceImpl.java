package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import softuni.exam.models.dto.json.BookSeedDTO;
import softuni.exam.models.entity.Book;
import softuni.exam.repository.BookRepository;
import softuni.exam.repository.BorrowingRecordRepository;
import softuni.exam.service.BookService;
import softuni.exam.util.ValidatorUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {
    private static final String JSON_FILES_PATH = "src/main/resources/files/json/";
    private static final String BOOKS_FILES = "books.json";
    private static final String LIBRARY_MEMBERS_FILES = "library-members.json";
    private final ValidatorUtil validatorUtil;
    private final Gson gson;
    private final ModelMapper mapper;
private final BookRepository bookRepository;
private final BorrowingRecordRepository borrowingRecordRepository;

    public BookServiceImpl(ValidatorUtil validatorUtil, Gson gson, ModelMapper mapper, BookRepository bookRepository, BorrowingRecordRepository borrowingRecordRepository) {
        this.validatorUtil = validatorUtil;
        this.gson = gson;
        this.mapper = mapper;
        this.bookRepository = bookRepository;
        this.borrowingRecordRepository = borrowingRecordRepository;
    }

    @Override
    public boolean areImported() {
        return bookRepository.count() > 0;
    }

    @Override
    public String readBooksFromFile() throws IOException {
        String content = Files
                .readString(Path.of(JSON_FILES_PATH + BOOKS_FILES));

        return content;
    }

    @Override
    public String importBooks() throws IOException {
        StringBuilder sb = new StringBuilder();
        
        BookSeedDTO[] bookSeedDTOS = this.gson.fromJson(
                new FileReader(JSON_FILES_PATH + BOOKS_FILES), BookSeedDTO[].class);

        for (BookSeedDTO bookSeedDTO : bookSeedDTOS) {
            Optional<Book> optional = bookRepository.findByTitle(bookSeedDTO.getTitle());

            if(!validatorUtil.isValid(bookSeedDTO) || optional.isPresent()){
                sb.append("Invalid book");
                sb.append(System.lineSeparator());
                continue;
            }

            Book book = mapper.map(bookSeedDTO, Book.class);
            book.setBorrowingRecords(borrowingRecordRepository.findByBookTitle(bookSeedDTO.getTitle()));

            bookRepository.save(book);

            sb.append(String.format("Successfully imported book %s - %s%n", book.getAuthor(), book.getTitle()));
        }


        return sb.toString();
    }
}
